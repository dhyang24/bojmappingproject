a = int(input())
b = []
def solve(start1,end1,start2,end2):
    if end1-start1 == 1:
        if b[start1][start2] == 0:
            return [0,1,0]
        elif b[start1][start2] == 1:
            return [0,0,1]
        else:
            return [1,0,0]
    anss = [0,0,0]
    temp = solve(start1,start1+(end1-start1)//3,start2,start2+(end2-start2)//3)
    anss[0]+=temp[0];anss[1]+=temp[1];anss[2]+=temp[2]
    temp = solve(start1+(end1-start1)//3,start1+(end1-start1)//3*2,start2,start2+(end2-start2)//3)
    anss[0]+=temp[0];anss[1]+=temp[1];anss[2]+=temp[2]
    temp = solve(start1+(end1-start1)//3*2,start1+(end1-start1)//3*3,start2,start2+(end2-start2)//3)
    anss[0]+=temp[0];anss[1]+=temp[1];anss[2]+=temp[2]
    temp = solve(start1,start1+(end1-start1)//3,start2+(end2-start2)//3,start2+(end2-start2)//3*2)
    anss[0]+=temp[0];anss[1]+=temp[1];anss[2]+=temp[2]
    temp = solve(start1+(end1-start1)//3,start1+(end1-start1)//3*2,start2+(end2-start2)//3,start2+(end2-start2)//3*2)
    anss[0]+=temp[0];anss[1]+=temp[1];anss[2]+=temp[2]
    temp = solve(start1+(end1-start1)//3*2,start1+(end1-start1)//3*3,start2+(end2-start2)//3,start2+(end2-start2)//3*2)
    anss[0]+=temp[0];anss[1]+=temp[1];anss[2]+=temp[2]
    temp = solve(start1,start1+(end1-start1)//3,start2+(end2-start2)//3*2,start2+(end2-start2)//3*3)
    anss[0]+=temp[0];anss[1]+=temp[1];anss[2]+=temp[2]
    temp = solve(start1+(end1-start1)//3,start1+(end1-start1)//3*2,start2+(end2-start2)//3*2,start2+(end2-start2)//3*3)
    anss[0]+=temp[0];anss[1]+=temp[1];anss[2]+=temp[2]
    temp = solve(start1+(end1-start1)//3*2,start1+(end1-start1)//3*3,start2+(end2-start2)//3*2,start2+(end2-start2)//3*3)
    anss[0]+=temp[0];anss[1]+=temp[1];anss[2]+=temp[2]
    if anss[0] == anss[1] == 0:
        return [0,0,1]
    elif anss[1] == anss[2] == 0:
        return [1,0,0]
    elif anss[0] == anss[2] == 0:
        return [0,1,0]
    else:
        return anss
for i in range(a):
    b.append(list(map(int,input().split())))
print(*solve(0,a,0,a),sep='\n')
