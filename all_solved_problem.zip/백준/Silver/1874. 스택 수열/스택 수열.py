from collections import deque
a = []
le = int(input())
for i in range(le):
   a.append(int(input()))
b = [po for po in range(1,le+1)]
c = deque()
d = []
alen = 0
ohno = []
while True:
   c.append(b.pop(0))
   ohno.append("+")
   while True:
      if len(c) == 0:
         break
      elif c[len(c)-1] == a[alen]:
         d.append(c.pop())
         ohno.append("-")
         alen+=1
      else:
         break
   if len(b) == 0:
      break
if d == a:
   for i in ohno:
      print(i)
else:
   print("NO")