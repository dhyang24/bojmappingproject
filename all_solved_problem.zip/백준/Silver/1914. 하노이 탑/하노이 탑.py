import sys
def do(n,a,b):
    if n == 1:
        sys.stdout.write(str(a)+" "+str(b)+'\n')
    else:
        do(n-1,a,6-a-b)
        sys.stdout.write(str(a)+" "+str(b)+'\n')
        do(n-1,6-a-b,b)
a = int(input())
if a <= 20:
    print((2**a)-1)
    do(a,1,3)
else:
    print((2**a)-1)