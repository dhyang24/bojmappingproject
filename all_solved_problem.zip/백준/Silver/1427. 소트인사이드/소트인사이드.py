a = list(input())
a.sort(reverse = True)
print("".join(a))