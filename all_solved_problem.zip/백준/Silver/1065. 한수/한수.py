su=0
for i in range(1,int(input())+1):
    if len(str(i)) == 1 or len(str(i)) == 2:
        su+=1
    elif len(str(i)) == 3:
        if int(str(i)[1]) - int(str(i)[0]) + int(str(i)[1]) == int(str(i)[2]):
            su+=1
print(su)