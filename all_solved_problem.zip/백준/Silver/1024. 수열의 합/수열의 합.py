a,b = map(int,input().split())
ans = []
for current in range(b,101):
    if current%2 == 1:
        if a/current == a//current:
            for i in range(current):
                ans.append(str(a//current-(current//2)+i))
    else:
        if (a-(current//2))/current == (a-(current//2))//current:
            for i in range(current):
                ans.append(str(a//current-(current//2)+i+1))
    if len(ans) != 0:
        break
if len(ans) == 0 or int(ans[0]) < 0:
    print(-1)
else:
    print(" ".join(ans))