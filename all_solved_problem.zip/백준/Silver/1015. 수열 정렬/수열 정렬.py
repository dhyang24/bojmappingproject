a,b = int(input()),list(map(int,input().split()))
c = sorted(b)
d = []
for i in b:
    for p in range(len(c)):
        if i == c[p]:
            while True:
                if p in d:
                    p+=1
                else:
                    break
            print(p,end=" ")
            d.append(p)
            break