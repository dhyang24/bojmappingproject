count = 0
for i in range(int(input())):
    p = {}
    st = input()+'!'
    temp = ''
    stat = True
    for z in st:
        if temp != z:
            if temp in p:
                stat = False
                break
            else:
                p[temp] = 1
            temp = z
    if stat == True:
        count+=1
print(count)