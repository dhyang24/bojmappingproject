import re
for i in range(int(input())):
    num,asd = input(), re.compile('(100+1+|01)+')
    if asd.fullmatch(num) != None: print("YES")
    else: print("NO")