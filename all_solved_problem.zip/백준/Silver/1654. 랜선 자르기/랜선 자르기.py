import sys
a,b = map(int,input().split())
c = []

for i in range(a):
   c.append(int(sys.stdin.readline()))
p,y = 1,max(c)
while p <= y:
   num = 0
   for i in c:
      num += i//((p+y)//2)
   if num >= b:
      p = (p+y)//2+1
   else:
      y = (p+y)//2-1
print(y)
      