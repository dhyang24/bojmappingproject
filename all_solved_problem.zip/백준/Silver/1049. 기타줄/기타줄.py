a,b = map(int,input().split())
c = []
d = []
for i in range(b):
    e,f = map(int,input().split())
    c.append(e)
    d.append(f)
num = min(min(c),min(d)*6)
if a >= 6:
    print(min(((a//6)*num) + (a%6)*min(d),((a//6)+1)*num))
else:
    print(min(min(d)*a,num))