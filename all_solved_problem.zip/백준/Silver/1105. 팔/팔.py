a,b = map(int,input().split())
mi = 2310913029021390291302931301290193209123
for i in range(a,b+1):
    num = str(i).count('8')
    if num < mi:
        mi = num
    if num == 0:
        break
print(mi)