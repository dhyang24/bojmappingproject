a = int(input())
b = list(map(int,input().split()))
su = [b[0]]
for i in range(len(b)-1):
    su.append(max(su[i]+b[i+1],b[i+1]))
print(max(su))