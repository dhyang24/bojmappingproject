import sys
a = list(sys.stdin.readline().strip())
cursor = len(a)
popopo = list()
for i in range(int(sys.stdin.readline())):
    c = list(map(str,sys.stdin.readline().split()))
    if c[0] == 'P':
        a.append(c[1])
    elif c[0] == 'L':
        if len(a) == 0:
            continue
        popopo.append(a.pop())
    elif c[0] == 'D':
        if len(popopo) == 0:
            continue
        a.append(popopo.pop())
    elif c[0] == 'B':
        if len(a) == 0:
            continue
        a.pop()
sys.stdout.write(''.join(a+popopo[::-1]))