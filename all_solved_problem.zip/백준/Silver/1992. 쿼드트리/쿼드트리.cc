#include<iostream>
#include<vector>
#include<algorithm>
#include<string>
using namespace std;
int datas[(1<<7)+10][(1<<7)+10];
pair<string,int> solve(int s1,int e1,int s2,int e2){
    if(s1 == e1 and s2 == e2){
        return make_pair("",datas[s1][s2]);
    }
    pair<string,int> temp1,temp2,temp3,temp4;
    temp1 = solve(s1,(s1+e1)/2,s2,(s2+e2)/2);
    temp2 = solve((s1+e1)/2+1,e1,(s2+e2)/2+1,e2);
    temp3 = solve((s1+e1)/2+1,e1,s2,(s2+e2)/2);
    temp4 = solve(s1,(s1+e1)/2,(s2+e2)/2+1,e2);
    if ((temp1.second == 2 or temp2.second == 2 or temp3.second == 2 or temp4.second == 2) or temp1 != temp2 or temp2 != temp3 or temp3 != temp4){
        string ans = "(";
        if(temp1.second == 1){
            ans+="1";
        }else if(temp1.second == 0){
            ans+="0";
        }else{
            ans+=temp1.first;
        }
        if(temp4.second == 1){
            ans+="1";
        }else if(temp4.second == 0){
            ans+="0";
        }else{
            ans+=temp4.first;
        }
        if(temp3.second == 1){
            ans+="1";
        }else if(temp3.second == 0){
            ans+="0";
        }else{
            ans+=temp3.first;
        }
        if(temp2.second == 1){
            ans+="1";
        }else if(temp2.second == 0){
            ans+="0";
        }else{
            ans+=temp2.first;
        }
        ans+=")";
        return make_pair(ans,2);
    }else{
        return make_pair("",temp1.second);
    }
}
int main(void){
    int a;
    string b;
    cin >> a;
    for(int i=0; i<a; i++){
        cin >> b;
        for(int j=0; j<a; j++){
            datas[i][j] = b[j]-'0';
        }
    }
    pair<string,int>ans = solve(0,a-1,0,a-1);
    if (ans.second == 0){
        cout << 0;
    }else if (ans.second == 1){
        cout << 1;
    }else{
        cout << ans.first;
    }
}
