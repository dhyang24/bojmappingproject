lis = []
for i in range(int(input())):
   lis.append(str(input()))
lis = list(set(lis))
lis.sort()
apple = []
for i in lis:
   apple.append(len(i))
for i in range(max(apple) ):
   for p in lis:
      if len(p) == i+1:
         print(p)