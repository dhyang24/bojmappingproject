from collections import deque
def dfs(cur):
    print(cur+1,end=' ')
    global d
    global visited
    visited[cur] = True
    for i in d[cur]:
        if visited[i] == False:
            dfs(i)
a,b,c = map(int,input().split())
d = [[] for i in range(a)]
for i in range(b):
    q,w = map(int,input().split())
    if w-1 not in d[q-1]:
        d[q-1].append(w-1)
    if q-1 not in d[w-1]:
        d[w-1].append(q-1)
visited = [False for i in range(a)]
for i in range(len(d)):
    d[i] = sorted(d[i])
dfs(c-1)
visited = [False for i in range(a)]
q = deque([c-1])
print()
while q:
    cur = q.popleft()
    print(cur+1,end=' ')
    visited[cur] = True
    for i in d[cur]:
        if not visited[i]:
            q.append(i)
            visited[i] = True
