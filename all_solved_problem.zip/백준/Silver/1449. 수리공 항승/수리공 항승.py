a,b = map(int,input().split())
c = sorted(map(int,input().split()),reverse=True)
ans = 0
while len(c) > 0:
    ans+=1
    temp = c.pop()
    remove = []
    for i in c:
        if i-temp<=b-1:
            remove.append(i)
    for i in remove:
        c.remove(i)
print(ans)