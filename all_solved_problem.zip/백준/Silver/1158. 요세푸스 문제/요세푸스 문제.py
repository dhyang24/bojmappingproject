from collections import deque
a,b= map(int,input().split())
c = deque([n+1 for n in range(a)])
p = []
while len(c) != 0:
    for i in range(b-1):
        temp = c[0]
        c.remove(c[0])
        c.append(temp)
    p.append(str(c.popleft()))
print('<'+', '.join(p)+'>')