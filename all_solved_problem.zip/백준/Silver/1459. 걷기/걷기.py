x,y,a,b = map(int,input().split())
print(min((x+y)*a,max(x,y)*b if (x+y)%2 == 0 else (max(x,y)-1)*b+a,min(x,y)*b+abs(x-y)*a))
