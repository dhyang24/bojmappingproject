import sys
input = sys.stdin.readline
print = sys.stdout.write
p,d = map(int,input().split())
di = {}
for i in range(p):
    a = input().strip()
    di[str(i+1)] = a
    di[a] = i+1
for i in range(d):
    a = input().strip()
    print(str(di[a])+'\n')