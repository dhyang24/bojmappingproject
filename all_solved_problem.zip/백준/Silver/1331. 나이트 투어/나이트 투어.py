visited = []
last = None
for i in range(36):
    a = input()
    if a[0] == 'A': b= 1
    if a[0] == 'B':b =2
    if a[0] == 'C':b=3
    if a[0] == 'D':b=4
    if a[0] == 'E':b=5
    if a[0] == 'F':b=6
    if last == None:
        visited.append([b,a[1]])
        last = [b,a[1]]
    else:
        if [b,a[1]] in visited:
            break
        if b + 2 == last[0] or b - 2 == last[0]:
            if int(a[1]) + 1 == int(last[1])or int(a[1])  - 1 == int(last[1]):
                visited.append([b,a[1]])
                last = [b,a[1]]
            else:
                break
        elif b + 1 == last[0] or b - 1 == last[0]:
            if int(a[1])  + 2 == int(last[1]) or int(a[1])  - 2 == int(last[1]):
                visited.append([b,a[1]])
                last = [b,a[1]]
            else:
                break
        else:
            break
if len(visited) == 36:
    if last[0] + 2 == visited[0][0] or last[0] - 2 == visited[0][0]:
        if int(last[1]) + 1 == int(visited[0][1])or int(a[1])  - 1 == int(visited[0][1]):
            print('Valid')
        else:
            print('Inalid')
    elif last[0] + 1 == visited[0][0] or last[0] - 1 == visited[0][0]:
        if int(last[1]) + 2 == int(visited[0][1])or int(a[1])  - 2 == int(visited[0][1]):
            print('Valid')
        else:
            print('Invalid')
    else:
        print('Invalid')
else:
    print('Invalid')