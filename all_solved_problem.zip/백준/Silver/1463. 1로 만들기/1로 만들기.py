import math
a = int(input())
b = [math.inf for i in range(a)]
b[0] = 0
for i in range(1,a):
    b[i] = min(b[i-1]+1,b[i])
    if (i+1)%3==0:
        b[i] = min(b[(i+1)//3-1]+1,b[i])
    if (i+1)%2==0:
        b[i] = min(b[(i+1)//2-1]+1,b[i])
print(b[a-1])
