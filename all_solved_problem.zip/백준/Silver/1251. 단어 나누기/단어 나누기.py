a = input()
ans = []
for i in range(len(a)-2):
    for z in range(i+1,len(a)-1):
        ans.append(a[:i+1][::-1]+a[i+1:z+1][::-1]+a[z+1:][::-1])
print(min(ans))