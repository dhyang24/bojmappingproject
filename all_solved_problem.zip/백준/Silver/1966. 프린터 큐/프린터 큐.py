for i in range(int(input())):
   a,b = map(int,input().split())
   c = list(map(int,input().split()))
   wich = [False for i in range(a)]
   wich[b] = True
   ohno = 0
   while True:
      if c[0] == max(c):
         ohno+=1
         if wich[0] == 1:
            break
         else:
            c.remove(c[0])
            wich.remove(wich[0])
      else:
         c.append(c.pop(0))
         wich.append(wich.pop(0))
   print(ohno)