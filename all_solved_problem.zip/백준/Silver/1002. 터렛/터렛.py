import math
n = int(input())
for i in range(n):
    a1,a2,r1,b1,b2,r2 = map(int, input().split())
    dis = math.sqrt((a1-b1)**2+(a2-b2)**2)
    if dis == 0 :
        if r1 == r2:
            print(-1)
        else:
            print(0)
    else:
        if dis < r1+r2:
            if dis + min(r1,r2) == max(r1,r2):    
                print(1)
            elif dis + min(r1,r2) < max(r1,r2):
                print(0)
            else:
                print(2)
        elif dis == r1+r2:
            print(1)
        else:
            print(0)