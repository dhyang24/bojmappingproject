a = int(input())
b = list(map(int,input().split()))
c = list(map(int,input().split()))
b.sort()
c.sort()
su = 0
for i in range(len(b)):
    su+=b[i]*(c[len(c)-i-1])
print(su)