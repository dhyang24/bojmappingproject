a= int(input())
b = list(map(int,input().split()))
total = 0
for i in b:
   yes = 0
   if i == 1:
      yes = 1
   else:
      for p in range(2,(i+1)//2+1):
         if i%p == 0:
            yes = 1
            break
   if yes == 0:
         total+=1
print(total)