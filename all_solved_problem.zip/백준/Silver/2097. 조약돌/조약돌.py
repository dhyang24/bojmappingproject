import math
a = int(input())
if math.floor(math.sqrt(a)) ==math.sqrt(a):
    print(max(4,math.floor(math.sqrt(a)-1)*4))
else:
    if math.floor(math.sqrt(a))*(math.floor(math.sqrt(a))+1) >= a:
        print(max(4,(math.floor(math.sqrt(a))-1)*4+2))
    else:
        print(max(4,(math.floor(math.sqrt(a))-1)*4+4))