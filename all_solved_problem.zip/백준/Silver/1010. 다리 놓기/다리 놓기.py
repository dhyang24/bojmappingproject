def f(b):
    a = 1
    for i in range(b):
        a = a * (i+1)
    return(a)
repeat = int(input())
for i in range(repeat):
    n,m = map(int,input().split())
    if m == 0:
        print(0)
    else:
        nf = int(f(n))
        mf = int(f(m))
        nmf = int(f(m-n))
        print(int(mf//nf//nmf))