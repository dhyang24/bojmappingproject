from collections import deque
import sys
input = sys.stdin.readline
print = sys.stdout.write
a,b = map(int,input().split())
data = []
counter = 0
for i in range(a):
    data.append(input())
q = deque([[0,0],[-1]])
visited = [[False for i in range(b)] for i in range(a)]
visited[0][0] = True
while True:
    if q[0][0] == -1:
        counter+=1
        q.append(q.popleft())
        continue
    if q[0][0] == a-1 and q[0][1] == b-1:
        break
    if len(data[q[0][0]]) != q[0][1]+1:
        if data[q[0][0]][q[0][1]+1] == '1':
            if visited[q[0][0]][q[0][1]+1] == False:
                q.append([q[0][0],q[0][1]+1])
                visited[q[0][0]][q[0][1]+1] = True
    if len(data) != q[0][0]+1:
        if data[q[0][0]+1][q[0][1]] == '1':
            if visited[q[0][0]+1][q[0][1]] == False:
                q.append([q[0][0]+1,q[0][1]])
                visited[q[0][0]+1][q[0][1]] = True
    if q[0][0] > 0 and data[q[0][0]-1][q[0][1]] == '1':
        if visited[q[0][0]-1][q[0][1]] == False:
            q.append([q[0][0]-1,q[0][1]])
            visited[q[0][0]-1][q[0][1]] = True
    if q[0][1] > 0 and data[q[0][0]][q[0][1]-1] == '1':
        if visited[q[0][0]][q[0][1]-1] == False:
            q.append([q[0][0],q[0][1]-1])
            visited[q[0][0]][q[0][1]-1] = True
    q.popleft()
print(str(counter+1))