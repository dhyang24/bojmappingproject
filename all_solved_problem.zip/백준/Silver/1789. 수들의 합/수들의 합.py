a = int(input())
num = 0
inc = 1
time = 0
while a >= num:
    num+=inc
    inc+=1
    time+=1
print(time-1)