from collections import Counter
import sys
a = []
for i in range(int(input())):
   a.append(int(sys.stdin.readline()))
a.sort()
print(round(sum(a)/len(a)))
print(a[len(a)//2])
potato = Counter(a)
mode = potato.most_common()
if len(mode) > 1:
   if mode[0][1] == mode[1][1]:
      print(mode[1][0])
   else:
      print(mode[0][0]) 
else:
   print(mode[0][0])
print(max(a)-min(a))