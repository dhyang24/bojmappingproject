a = int(input())
for i in range(a):
    b = list(map(int,input().split()))
    if i == 0:
        temp=b
        continue
    else:
        temp2 = []
        for i in range(len(b)):
            try:
                if i-1 >= 0:
                    temp2.append(max(b[i]+temp[i],b[i]+temp[i-1]))
                else:
                    temp2.append(b[i]+temp[i])
            except:
                temp2.append(b[i]+temp[i-1])
        temp = temp2
print(max(temp))