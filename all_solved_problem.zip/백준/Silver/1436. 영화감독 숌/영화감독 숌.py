a = int(input())
zd = 0
for i in range(100000000000):
   if "666" in str(i):
      zd+=1
   if zd == a:
      print(i)
      break
