import math
import sys
a,b = map(int,sys.stdin.readline().split())
lis = ""
for p in range(a,b+1):
   yes = True
   if p == 1:
      yes = False
   for i in range(2,int(math.sqrt(b))+1):
      if p%i == 0:
         if p != i:
            yes = False
            break
   if yes == True:
      lis+=str(p)+"\n"
sys.stdout.write(lis)