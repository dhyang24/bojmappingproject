def findrelation(arr, persontofind, depth):
   if depth == 0:
      return None
   if depth == 1:
      potato = []
      for i in range(len(arr[persontofind])):
         if arr[persontofind][i]=='Y':
            potato.append(i)
      potato.append(persontofind)
      return potato
   if depth == 2:
      lis = []
      ans = []
      for i in range(len(arr[persontofind])):
         if arr[persontofind][i]=='Y':
            lis.append(i)
      for i in lis:
         a = findrelation(arr,i,1)
         for z in a:
            ans.append(z)
      return list(set(ans))
people = int(input())
relation = []
for i in range(people):
   relation.append(input())
ans = []
for i in range(people):
   ans.append(max(len(findrelation(relation,i,2))-1,0))
print(max(ans))