a = int(input())
su = 0
for i in range(7):
   if (1<<i)&a:
      su+=1
print(su)