a = int(input())
b = list(map(int,input().split()))
c = int(input())
temp = c
ans = [0,0]
while temp not in b and temp > 0:
    ans[0]+=1
    temp-=1
temp = c
while temp not in b:
    ans[1]+=1
    temp+=1
print(max(0,ans[0]*ans[1]-1))
