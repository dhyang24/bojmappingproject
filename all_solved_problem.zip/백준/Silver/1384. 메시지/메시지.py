group = 0
while True:
    group +=1
    a = int(input())
    if a == 0:
        break
    data = []
    stat = False
    print("Group",group)
    for i in range(a):
        data.append(list(map(str,input().split())))
    for i in range(a):
        qqq = i
        for p in range(1,len(data[i])):
            if data[i][p] == "N":
                idx = i
                for z in range(p):
                    idx-=1
                    idx = (idx+a)%a
                stat = True
                print(data[idx][0],"was nasty about",data[qqq][0])
    if not stat:
        print("Nobody was nasty")
    print()        
