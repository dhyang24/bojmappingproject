from collections import deque
d = deque([i for i in range(1,int(input())+1)])
while d:
    print(d.popleft(),end = ' ')
    if not d:
        break
    d.append(d.popleft())