a = []
stat = [0 for i in range(24)]
ans = 0
for i in range(10):
    a.append(input())
if a[0][1] == '-':stat[0]=1
if a[0][4] == '-':stat[1]=1
if a[0][7] == '-':stat[2]=1
if a[3][1] == '-':stat[3]=1
if a[3][4] == '-':stat[4]=1
if a[3][7] == '-':stat[5]=1
if a[6][1] == '-':stat[6]=1
if a[6][4] == '-':stat[7]=1
if a[6][7] == '-':stat[8]=1
if a[9][1] == '-':stat[9]=1
if a[9][4] == '-':stat[10]=1
if a[9][7] == '-':stat[11]=1
if a[1][0] == '|':stat[12]=1
if a[1][3] == '|':stat[13]=1
if a[1][6] == '|':stat[14]=1
if a[1][9] == '|':stat[15]=1
if a[4][0] == '|':stat[16]=1
if a[4][3] == '|':stat[17]=1
if a[4][6] == '|':stat[18]=1
if a[4][9] == '|':stat[19]=1
if a[7][0] == '|':stat[20]=1
if a[7][3] == '|':stat[21]=1
if a[7][6] == '|':stat[22]=1
if a[7][9] == '|':stat[23]=1
if stat[0] and stat[12] and stat[13] and stat[3]:ans+=1
if stat[1] and stat[13] and stat[14] and stat[4]:ans+=1
if stat[2] and stat[14] and stat[15] and stat[5]:ans+=1
if stat[3] and stat[16] and stat[17] and stat[6]:ans+=1
if stat[4] and stat[17] and stat[18] and stat[7]:ans+=1
if stat[5] and stat[18] and stat[19] and stat[8]:ans+=1
if stat[6] and stat[20] and stat[21] and stat[9]:ans+=1
if stat[7] and stat[21] and stat[22] and stat[10]:ans+=1
if stat[8] and stat[22] and stat[23] and stat[11]:ans+=1
if stat[0] and stat[1] and stat[12] and stat[14] and stat[16] and stat[18] and stat[6] and stat[7]:ans+=1
if stat[1] and stat[2] and stat[13] and stat[15] and stat[17] and stat[19] and stat[7] and stat[8]:ans+=1
if stat[3] and stat[4] and stat[16] and stat[18] and stat[20] and stat[22] and stat[9] and stat[10]:ans+=1
if stat[4] and stat[5] and stat[17] and stat[19] and stat[21] and stat[23] and stat[10] and stat[11]:ans+=1
if stat[0] and stat[1] and stat[2] and stat[9] and stat[10] and stat[11] and stat[12] and stat[15] and stat[16] and stat[19]and stat[20] and stat[23]:ans+=1
print(24-sum(stat),ans)
