def jun(array,target):
    a = None
    b = None
    for i in array:
        if i[0] == target:
            a = i[1]
            b = i[2]
            break
    ans = target
    if a != '.':
        ans+=jun(array,a)
    if b != '.':
        ans+=jun(array,b)
    return ans
def jung(array,target):
    a = None
    b = None
    for i in array:
        if i[0] == target:
            a = i[1]
            b = i[2]
            break
    ans = ''
    if a != '.':
        ans+=jung(array,a)
    ans += target
    if b != '.':
        ans+=jung(array,b)
    return ans
def hu(array,target):
    a = None
    b = None
    for i in array:
        if i[0] == target:
            a = i[1]
            b = i[2]
            break
    ans = ''
    if a != '.':
        ans+=hu(array,a)
    if b != '.':
        ans+=hu(array,b)
    ans+=target
    return ans
a = int(input())
b = []
for i in range(a):
    b.append(list(map(str,input().split())))
print(jun(b,'A'),jung(b,'A'),hu(b,'A'),sep='\n')