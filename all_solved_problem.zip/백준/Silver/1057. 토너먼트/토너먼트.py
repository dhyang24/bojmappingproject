a,b,c = map(int,input().split())
su = 0
while True:
    su+=1
    b = (b+1)//2
    c = (c+1)//2
    if b == c:
        print(su)
        break