z,b = map(int,input().split())
arr = []
for i in range(z):
   arr.append(input())
ans = []
for i in range(z):
   for j in range(b):
      for l in range(min(z,b,z-i,b-j)):
         a = arr[i][j]
         if a == arr[i+l][j] and a == arr[i][j+l] and a == arr[i+l][j+l]:
            if len(ans) == 0 or (l+1)**2 > max(ans):
               ans.append((l+1)**2)
print(max(ans))