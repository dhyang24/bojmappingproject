a,b = map(int,input().split());lis = [];num = []
for i in range(a):lis.append(input())
for i in range(a-7):
   for p in range(b-7):
      whitenum =0;blacknum= 0
      for o in range(8):
         for l in range(8):
            zed = str(lis[i+o])[p+l]
            if (o+l)%2 == 0:
               if zed == "W":whitenum+=0; blacknum+=1
               else:whitenum+=1; blacknum+=0
            elif (o+l)%2 == 1:
               if zed == "W":whitenum+=1;blacknum+=0
               else:whitenum+=0;blacknum+=1
      num.append(min(whitenum,blacknum))
print(min(num))
