from collections import deque
a = int(input())
lis = deque(range(1,a+1))
while True:
   if len(lis) == 1:
      break
   lis.popleft()
   lis.append(lis.popleft())
print(lis[0])