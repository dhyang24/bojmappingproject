import sys
ropes = []
for i in range(int(sys.stdin.readline())):
    ropes.append(int(sys.stdin.readline()))
ropes.sort(reverse = True)
currentans = ropes[0]
index = 1
for i in range(1,len(ropes)):
    z = ropes[i]*(i+1)
    if z > currentans:
        currentans = z
    else:
        pass
    index+=1
print(currentans)