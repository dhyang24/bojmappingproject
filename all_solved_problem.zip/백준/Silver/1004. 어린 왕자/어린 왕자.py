for a in range(int(input())):
    x1,y1,x2,y2 = map(int,input().split())
    cnt = 0
    for p in range(int(input())):
        cx,cy,r = map(int,input().split())
        wert = (abs(x1-cx)**2)+(abs(y1-cy)**2)
        qwer = (abs(x2-cx)**2)+(abs(y2-cy)**2)
        if wert < r**2:
            if qwer < r**2:pass
            else:cnt+=1
        else:
            if qwer < r**2:cnt+=1
            else:pass
    print(cnt)