a,b = map(int,input().split())
c = list(map(int,input().split()))
d = [0]*a
ans = 0
while True:
    d[0]+=1
    ale = 0
    for i in range(len(d)):
        if d[i] == 2:
            if i+1 == len(d):
                ale = 1
                break
            else:
                d[i]-=2
                d[i+1]+=1
    if ale == 1:
        break
    su = 0
    for i in range(len(d)):
        if d[i] == 1:
            su+=c[i]
    if su == b:
        ans+=1
print(ans)