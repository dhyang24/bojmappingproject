import heapq
import sys
lis = []
for i in range(int(sys.stdin.readline())):
    a = int(sys.stdin.readline())
    if a == 0:
        if len(lis) == 0:
            sys.stdout.write('0\n')
        else:
            sys.stdout.write(str(heapq.heappop(lis))+'\n')
    else:
        heapq.heappush(lis,a)