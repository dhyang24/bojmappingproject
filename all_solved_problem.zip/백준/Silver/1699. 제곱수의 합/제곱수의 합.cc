#include <stdio.h>
int main(void){
    int a;
    scanf("%d",&a);
    int b[a+1];
    for(int i=0;i<a+1;i++){
        b[i]=99999999;
    }
    b[0]=0;
    for(int i=0;i<a+1;i++){
        int num = 1;
        while(i+(num*num)<=a){
            b[i+(num*num)]=(b[i]+1<b[i+(num*num)] ? b[i]+1 : b[i+num*num]);
            num++;
        }
    }
    printf("%d",b[a]);
}