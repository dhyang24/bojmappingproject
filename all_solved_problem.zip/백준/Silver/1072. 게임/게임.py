import math
from decimal import Decimal
a,b = map(int,input().split())
stat = True
thing1,thing2 = a,b
if math.floor(100*(thing2+123408989000)/(thing1 + 123408989000)) == math.floor(100*b/a):
    stat = False
    print(-1)
else:
    lo = 0
    hi = 1329809123081823
    while lo < hi:
        mid = (lo+hi)//2
        if math.floor(100*(b+mid)/(a+mid)) > math.floor(100*(b)/(a)):
            hi = mid
        elif math.floor(100*(b+mid)/(a+mid)) <= math.floor(100*(b)/(a)):
            lo = mid+1
    print(hi)
