a,b = map(int,input().split())
a = int(a)
b = int(b)
c = [i for i in range(1,a+1)]
d = list(map(int,input().split()))
ans = 0
for i in d:
    indexdsf = (len(c)-1)/2
    index = c.index(i)
    if index > indexdsf:
        while c[0] != i:
            temp = c[len(c)-1]
            c.remove(temp)
            c.insert(0,temp)
            ans+=1
        c.remove(c[0])
    else:
        while c[0] != i:
            temp = c[0]
            c.remove(c[0])
            c.append(temp)
            ans+=1
        c.remove(c[0])
print(ans)