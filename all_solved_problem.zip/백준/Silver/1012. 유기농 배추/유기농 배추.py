def find(x,y):
    c.remove([x,y])
    if [x+1,y] in c:
        find(x+1,y)
    if [x-1,y] in c:
        find(x-1,y)
    if [x,y+1] in c:
        find(x,y+1)
    if [x,y-1] in c:
        find(x,y-1)
for a in range(int(input())):
    b,c,e = map(int,input().split())
    count = 0
    c = []
    for i in range(e):
        x,y = map(int,input().split())
        c.append([x,y])
    while len(c) > 0:
        for zdfa in c:
            count+=1
            x = zdfa[0]
            y = zdfa[1]
            find(x,y)
    print(count)