import sys
party = {}
def fibonacci(n):
   n = int(n)
   if n in party.keys():
      return party[n]
   elif (n==0):
      party[0] = 0
   elif n==1:
      party[1] = 1
   else:
      party[n] = fibonacci(n-1) + fibonacci(n-2)
   return party[n]
for i in range(int(input())):
   a = int(sys.stdin.readline())
   if a == 0:
      print(1,0)
   else:
      sys.stdout.write("{pota}\n".format(pota =str(fibonacci(a-1))+" "+str(fibonacci(a))))