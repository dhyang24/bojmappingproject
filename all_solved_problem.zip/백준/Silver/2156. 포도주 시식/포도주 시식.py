a = int(input())
b = []
for i in range(a):
    b.append(int(input()))
if a == 1 or a == 2:
    print(sum(b))
else:
    c1 = [0,b[0],0]
    c2 = [max([c1[0],c1[1],c1[2]]),c1[0]+b[1],c1[1]+b[1]]
    c1[1] = b[0]
    for i in range(2,a):
        temp = [max([c2[0],c2[1],c2[2]]),max(c2[0]+b[i],c1[0]+b[i],c1[1]+b[i],c1[2]+b[i]),c2[1]+b[i]]
        c1 = c2
        c2 = temp
    print(max(c1+c2+temp)) 