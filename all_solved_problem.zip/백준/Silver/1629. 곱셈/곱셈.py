def q(a,b,c):
    if b == 0: return 1
    if b%2==0:
        return q(a,b//2,c)**2%c
    else:
        return a*((q(a,b//2,c)**2)%c)%c
a,b,c=map(int,input().split())
print(q(a,b,c))
