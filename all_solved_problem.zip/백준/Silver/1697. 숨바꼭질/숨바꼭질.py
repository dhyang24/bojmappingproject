from collections import deque
start,end = map(int,input().split())
visit = [0 for i in range(1000001)]
q = deque()
q.append(start)
q.append(-1)
cnt = 0
while True:
    if q[0] == end:
        break
    if q[0] == -1:
        cnt+=1
        q.popleft()
        q.append(-1)
        continue
    visit[q[0]] = 1
    if q[0]-1 >= 0 and visit[q[0]-1] == 0:
        q.append(q[0]-1)
    if q[0]+1 <= end and visit[q[0]+1] == 0:
        q.append(q[0]+1)
    if abs(q[0]*2-end)<abs(q[0]-end) and visit[q[0]*2] == 0:
        q.append(q[0]*2)
    q.popleft()
print(cnt)