a = int(input())
print(a//5+a//25+a//125)