a,b,c = map(int,input().split())
length = 2**a
total = 0
for i in range(a):
    if b >= length//2:
        if c >= length//2:
            b-=length//2
            c-=length//2
            total+=(length//2)**2*3
        elif c < length//2:
            b-=length//2
            total+=(length//2)**2*2
    elif b < length//2:
        if c >= length//2:
            c-=length//2
            total+=(length//2)**2*1
        elif c < length//2:
            pass
    length = length//2
print(total)