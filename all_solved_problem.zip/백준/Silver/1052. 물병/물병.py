n,k = map(int,input().split())
c = []
su = 0
while True:
    a = 1
    while a <= n:
        a*=2
    a = a // 2
    n = n-a
    c.append(a)
    if n == 1:
        c.append(n)
        break
    if n == 0:
        break
if len(c) <= k:
    print(0)
else:
    while len(c) > k:
        temp = c.pop()
        su+=temp
        while temp*2 in c:
            temp = c.pop()
        c.append(temp*2)
    print(su)