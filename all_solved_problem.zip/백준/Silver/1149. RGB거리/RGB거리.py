import sys
q=sys.stdin.readline;i=int;m=min;l=map;o=list;a=i(q());b=o(l(i,q().split()))
for w in range(a-1):
    z=o(l(i,q().split()));t=[m(z[0]+b[1],z[0]+b[2]),m(z[1]+b[0],z[1]+b[2]),m(z[2]+b[1],z[2]+b[0])];b=t
print(m(b))
