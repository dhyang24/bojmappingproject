a = []
currenttime = 0
num = 0
for i in range(int(input())):
    a.append(list(map(int,input().split())))
a.sort()
a.sort(key = lambda k:k[1])
for i in range(len(a)):
    if currenttime <= a[i][0]:
        num+=1
        currenttime = a[i][1]
print(num)