a,b = map(int,input().split())
lis1 = []
lis2 = []
ans = []
for i in range(a):
   lis1.append(input())
for i in range(b):
   lis2.append(input())
lis2.sort()
for i in lis1:
   start = 0
   end = len(lis2)-1
   stat = False
   while start<=end:
      mid = (start+end)//2
      if lis2[mid] == i:
         stat = True;break
      elif sorted([lis2[mid],i]) == [lis2[mid],i]:
         start = mid+1
      else:
         end = mid-1
   if stat == True:
      ans.append(i)
print(len(ans))
ans.sort()
for i in ans:
   print(i)