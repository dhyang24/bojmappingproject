def dfs(cur,h):
    visited[cur] = True
    height[cur] = h
    for i in graph[cur]:
        if not visited[i[0]]:
            dfs(i[0],h+1)
            sparsetemp[i[0]] = [cur,[i[1]]]
def getlca(a,b):
    q,w = sorted([a,b],key= lambda k:height[k])
    temp = height[w]-height[q]
    ans =[]
    for i in range(18):
        if (2**i)&(temp):
            ans=sorted(list(set(ans+sparse[i][w][1])),reverse = True)[:2]
            w = sparse[i][w][0]
    for i in range(17,-1,-1):
        if sparse[i][q][0] == sparse[i][w][0]:
            continue
        else:
            ans=sorted(list(set(ans+sparse[i][q][1]+sparse[i][w][1])),reverse = True)[:2]
            q = sparse[i][q][0]
            w = sparse[i][w][0]
    if q == w:
        return ans
    else:
        return sorted(list(set(ans+sparse[0][q][1]+sparse[0][w][1])),reverse = True)[:2]
import sys
import heapq
import math
print = sys.stdout.write
input = sys.stdin.readline
sys.setrecursionlimit(10**4*5)
a,b = map(int,input().split())
graph = [[] for i in range(a)]
lines = []
for i in range(b):
    q,w,e = map(int,input().split())
    lines.append([q-1,w-1,e])
    graph[q-1].append([e,w-1,q-1])
    graph[w-1].append([e,q-1,w-1])
b = []
for i in graph[0]:
    heapq.heappush(b,i)
visited = [False for i in range(a)]
visited[0] = True
ans1 = 0
graph2 = [[] for i in range(a)]
while b:
    temp = heapq.heappop(b)
    if visited[temp[1]]:
        continue
    graph2[temp[2]].append([temp[1],temp[0]])
    graph2[temp[1]].append([temp[2],temp[0]])
    visited[temp[1]] = True
    ans1+=temp[0]
    for i in graph[temp[1]]:
        if visited[i[1]] == False:
            heapq.heappush(b,i)
if False in visited:
    print("-1\n")
    sys.exit()
graph = graph2
sparse = []
sparsetemp = [[0,[]] for i in range(a)]
height = [-1 for i in range(a)]
height[0] = 0
visited = [False for i in range(a)]
dfs(0,0)
sparse.append(sparsetemp)
for i in range(18):
    sparsetemp = []
    for p in range(a):
        sparsetemp.append([sparse[-1][sparse[-1][p][0]][0],sorted(list(set(sparse[-1][p][1]+sparse[-1][sparse[-1][p][0]][1])),reverse = True)[:2]])
    sparse.append(sparsetemp)
mn = -1
for i in range(len(lines)):
    stuff =ans1+lines[i][2]
    thing = getlca(lines[i][0],lines[i][1])
    stuff-=thing[0]
    if mn == -1 and stuff != ans1:
        mn = stuff
    elif mn == -1 and len(thing) > 1 and stuff+thing[0]-thing[1] != ans1:
        mn = stuff+thing[0]-thing[1]
    if stuff != ans1:
        mn = min(stuff,mn)
    elif len(thing) > 1 and stuff+thing[0]-thing[1] != ans1:
        mn = min(stuff+thing[0]-thing[1],mn)
if mn == -1:
    print("-1\n")
else:
    print(str(mn)+'\n')
