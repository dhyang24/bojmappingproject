import math
import sys
input = sys.stdin.readline
print = sys.stdout.write
a,b = map(int,input().split())
c = list(map(int,input().split()))+[math.inf]
d = list(map(int,input().split()))+[math.inf]
cpoint = 0
dpoint = 0
merged = []
dp = [0]
while True:
    if cpoint == a and dpoint == b:
        break
    if c[cpoint] < d[dpoint]:
        merged.append((c[cpoint]+1)*-1)
        cpoint+=1
    else:
        merged.append(d[dpoint]+1)
        dpoint+=1
c,d = None,None
near = []
last0 = []
last1 = []
for i in range(len(merged)):
    if merged[i] < 0:
        last0.append([i,(abs(merged[i])-1)])
        if len(last1) != 0:
            for qwer in range(len(last1)):
                if near[last1[qwer][0]][1] == -1 or near[last1[qwer][0]][1] > abs(last1[qwer][1]-(abs(merged[i])-1)):
                    near[last1[qwer][0]] = [i,abs(last1[qwer][1]-(abs(merged[i])-1))]
            near.append([last1[-1][0],abs(last1[-1][1]-(abs(merged[i])-1))])
            last1 = [last1[-1]]
        else:
            near.append([-1,-1])
    if merged[i] > 0:
        last1.append([i,(abs(merged[i])-1)])
        if len(last0) != 0:
            for qwer in range(len(last0)):
                if near[last0[qwer][0]][1] == -1 or near[last0[qwer][0]][1] > abs(last0[qwer][1]-(abs(merged[i])-1)):
                    near[last0[qwer][0]] = [i,abs(last0[qwer][1]-(abs(merged[i])-1))]
            near.append([last0[-1][0],abs(last0[-1][1]-(abs(merged[i])-1))])
            last0 = [last0[-1]]
        else:
            near.append([-1,-1])
last1,last0 = None,None
balance = 0
lastbalance = [-1 for i in range(len(merged)*2+2)]
lastbalance[balance+len(merged)+1] = 0
su1 = [0 for i in range(len(merged)+1)]
merge2 = [-1 for i in range(len(merged))]
for i in range(len(merged)):
    if merged[i] > 0:
        balance+=1
        su1[i+1] = su1[i] + (abs(merged[i])-1)
    else:
        balance-=1
        su1[i+1] = su1[i] - (abs(merged[i])-1)
    if lastbalance[balance+len(merged)+1] != -1:
        merge2[i] = lastbalance[balance+len(merged)+1]
    lastbalance[balance+len(merged)+1] = i+1
lastbalance = None
for i in range(len(merged)):
    if merge2[i] != -1:
        dp.append(min(dp[-1]+near[i][1],dp[merge2[i]]+abs(su1[i+1]-su1[merge2[i]])))
    else:
        dp.append(dp[-1]+near[i][1])
print(str(dp[-1])+'\n')
        
