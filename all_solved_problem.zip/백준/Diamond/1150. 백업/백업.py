import heapq
import sys
import math
input = sys.stdin.readline
print = sys.stdout.write
a,b = map(int,input().split())
c = []
d = [[math.inf,0,0]]
m = []
for i in range(a):
    c.append(int(input()))
for i in range(1,a):
    d.append([c[i]-c[i-1],i-1,i+1])
    heapq.heappush(m,[d[-1][0],i])
d.append([math.inf,0,0])
ans = 0
visited = [False for i in range(a+3)]
for i in range(b):
    temp = heapq.heappop(m)
    while visited[temp[1]]:
        temp = heapq.heappop(m)
    ans+=temp[0]
    visited[d[temp[1]][1]] = True
    visited[d[temp[1]][2]] = True
    d[temp[1]][0] = d[d[temp[1]][1]][0]+d[d[temp[1]][2]][0]-d[temp[1]][0]
    d[temp[1]][1] = d[d[temp[1]][1]][1]
    d[temp[1]][2] = d[d[temp[1]][2]][2]
    d[d[temp[1]][1]][2] = temp[1]
    d[d[temp[1]][2]][1] = temp[1]
    heapq.heappush(m,[d[temp[1]][0],temp[1]])
print(str(ans)+'\n')
