import math
inf = 1000000
thing = [1 for i in range(inf)]
num = int(input())
def cnt(a):
    global thing
    ans = 0
    for i in range(1,math.floor(math.sqrt(a))+1):
        ans+=thing[i]*(a//(i**2))
    return ans
for i in range(2,math.floor(math.sqrt(inf))+1):
    if thing[i] == 1:
        for l in range(i,inf,i):
            thing[l] *=-i
        for l in range(i*i,inf,i*i):
            thing[l]=0
for i in range(2,inf):
    if thing[i] == i:
        thing[i] = 1
    elif thing[i] == -i:
        thing[i] = -1
    elif thing[i] < 0:
        thing[i] = 1
    elif thing[i] > 0:
        thing[i] = -1
s,e = 0,1000000000000
while s+1 < e:
    m = (s+e)//2
    if cnt(m) < num:
        s = m
    else:
        e = m
print(e)
