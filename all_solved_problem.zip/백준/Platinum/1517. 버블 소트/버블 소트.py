import math
import bisect
a = int(input())
lis = list(map(int,input().split()))
b=sorted(list(set(lis)))
for i in range(len(lis)):
    lis[i] = bisect.bisect_left(b,lis[i])+1
stat = [[0 for i in range(a)]]
stat[0][lis[0]-1] = 1
for i in range(math.ceil(math.log(a,2))):
    temp = []
    for q in range(0,math.ceil(len(stat[-1])),2):
        try:
            temp.append(stat[-1][q]+stat[-1][q+1])
        except:
            temp.append(stat[-1][q])
    stat.append(temp)
ans = 0
for i in range(1,a):
    temp = 0
    for q in range(math.ceil(math.log(a,2)),-1,-1):
        if lis[i]&(2**q):
            temp+=stat[q][(lis[i])//(2**q)-1]
    ans+=stat[-1][-1]-temp
    for q in range(math.ceil(math.log(a,2))+1):
        stat[q][(lis[i]-1)//(2**q)]+=1
print(ans)