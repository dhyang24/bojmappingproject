import copy
def stringize(a,le):
    a = str(a)
    st = ''
    for i in range(le-len(str(a))):
        st+='0'
    return st+a

def getval(a,lis):
    val = 0
    for i in a:
        val+=lis[int(i)]
    return val
lis = [6,2,5,5,4,5,6,3,7,5]
a = input()
originala = a
val = getval(a,lis)
ans = 0
le = len(a)
ma = 10**len(a)-1
found = False
'''
q=a
while True:
    if int(q)+1 > ma:
        q = stringize(int(q)+1-10**le,le)
    else:
        q = stringize(int(q)+1,le)
    if getval(q,lis) == val:
        if int(originala) >= int(q):
            print(int(q)+10**le-int(originala))
        else:
            print(int(q)-int(originala))
        break
        '''
for i in range(int(a[-1])+1,10):
    if lis[int(a[-1])] == lis[i]:
        found = True
        ans = int(a) + (i-int(a[-1]))
        break

if found == False:
    if int(a)+1 > ma:
        a = stringize(int(a)+1-10**le,le)
    else:
        a = stringize(int(a)+1,le)
    while found == False:
        stat = False
        for i in range(le+1):
            temp = a[:(le-i)]
            tempval = getval(temp,lis)
            if val >= (tempval)+2*i and val <= (tempval)+7*i:
                if i==0:
                    found = True
                    ans = temp
                    stat = True
                    break
                else:
                    if int(a)+10**(i-1) > ma:
                        a = stringize(int(a)+10**(i-1)-10**le,le)
                    else:
                        a = stringize(int(a)+10**(i-1),le) 
                    stat = True
                    break
        if stat == False:
            if int(a)+10**(le-1) > ma:
                a = stringize(int(a)+10**(le-1)-10**le,le)
            else:
                a = stringize(int(a)+10**(le-1),le)
                
if int(originala) >= int(ans):
    print(int(ans)+10**le-int(originala))
else:
    print(int(ans)-int(originala))

