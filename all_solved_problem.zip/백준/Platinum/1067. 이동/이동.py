import math
import decimal
def fft(lis,cp,n):
    if n == 1:
        return lis
    even,odd = [], []
    for i in range(n):
        if i%2: odd.append(lis[i])
        else: even.append(lis[i])
    even = fft(even,cp*cp,n//2)
    odd = fft(odd,cp*cp,n//2)
    w = complex(1,0)
    for i in range(n//2):
        lis[i] = even[i]+ (w*odd[i])
        lis[i+n//2] = even[i] - (w*odd[i])
        w=w*cp
    return lis
def multi(a,b):
    n=1
    while n<=(len(a)+len(b)): n= n<<1;
    w= complex(math.cos(2*math.pi/n),math.sin(2*math.pi/n))
    while len(a) < n:
        a.append(0)
    while len(b) < n:
        b.append(0)
    a = fft(a,w,n)
    b = fft(b,w,n)
    ab = []
    for i in range(n): ab.append(a[i]*b[i])
    ab = fft(ab, complex(w.real,-w.imag),n)
    for i in range(n):
        ab[i] = ab[i] / complex(n,0)
        ab[i] = int(round(ab[i].real))
    return ab
le = int(input())
a = list(map(int,input().split()))
b = list(map(int,input().split()))
c = multi(a+a,b[::-1])
print(max(c))
    
