import sys
sys.setrecursionlimit(10**5*2)
a = int(input())
b = []
for i in range(a):
    b.append(int(input()))
def solve(start,end):
    if start > end:
        return 0
    if start == end:
        return b[start]
    mid = (start+end)//2
    mx = b[mid]
    ans = 1
    cur = b[mid]
    cur1 = mid
    cur2 = mid
    while True:
        if cur1 == start and cur2 == end:
            break
        elif cur1 == start:
            ans+=1
            cur2+=1
            cur=min(b[cur2],cur)
            mx = max(mx,ans*cur)
        elif cur2 == end:
            ans+=1
            cur1-=1
            cur=min(b[cur1],cur)
            mx = max(mx,ans*cur)
        else:
            if b[cur1-1] > b[cur2+1]:
                ans+=1
                cur1-=1
                cur=min(b[cur1],cur)
                mx = max(mx,ans*cur)
            else:
                ans+=1
                cur2+=1
                cur=min(b[cur2],cur)
                mx = max(mx,ans*cur)
    return max([mx,solve(start,mid-1),solve(mid+1,end)])
print(solve(0,a-1))
    
