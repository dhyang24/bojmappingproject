import sys
sys.setrecursionlimit(10**5*2)
a = int(input())
b = list(map(int,input().split()))
def solve(start,end):
    if start > end:
        return 0
    if start == end:
        return b[start]**2
    mid = (start+end)//2
    mx = b[mid]**2
    ans = b[mid]
    cur = b[mid]
    cur1 = mid
    cur2 = mid
    while True:
        if cur1 == start and cur2 == end:
            break
        elif cur1 == start:
            ans+=b[cur2+1]
            cur2+=1
            cur=min(b[cur2],cur)
            mx = max(mx,ans*cur)
        elif cur2 == end:
            ans+=b[cur1-1]
            cur1-=1
            cur=min(b[cur1],cur)
            mx = max(mx,ans*cur)
        else:
            if b[cur1-1] > b[cur2+1]:
                ans+=b[cur1-1]
                cur1-=1
                cur=min(b[cur1],cur)
                mx = max(mx,ans*cur)
            else:
                ans+=b[cur2+1]
                cur2+=1
                cur=min(b[cur2],cur)
                mx = max(mx,ans*cur)
    return max([mx,solve(start,mid-1),solve(mid+1,end)])
print(solve(0,a-1))
    
