import sys
input = sys.stdin.readline
print = sys.stdout.write
def isbigger(t1,t2):
    if t1[0]>=t2[0] and t1[1]>=t2[1] and t1[2]>=t2[2]:return True
    else:return False
def dfs(cur):
    global graph
    global visited
    global current
    if visited[cur]:
        return False
    visited[cur] = True
    for i in graph[cur]:
        if dfs2(cur,i) and (current[i] == -1 or dfs(current[i])):
            current[i] = cur
            return True
    return False
def dfs2(cur,start):
    if current[cur] == start:
        return False
    if current[cur] == -1:
        return True
    return dfs2(current[cur],start)
        
a = int(input())
graph = [[] for i in range(a)]
thing = []
for i in range(a):
    thing.append(list(map(int,input().split())))
for i in range(a-1):
    for p in range(i+1,a):
        if isbigger(thing[i],thing[p]):
            graph[i].append(p)
        elif isbigger(thing[p],thing[i]):
            graph[p].append(i)
current = [-1 for i in range(a)]
ans = 0
for i in range(a):
    visited = [False for i in range(int(a))]
    if dfs(i):
        ans+=1
for i in range(a):
    visited = [False for i in range(int(a))]
    if dfs(i):
        ans+=1
print(str(a-ans)+'\n')
