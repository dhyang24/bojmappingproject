#include<iostream>
#include<cstring>
using namespace std;
int length;
long long memo[110][110][2];
long long count(int position, int wrongstat, int curpar){
    if(position == length){
        if(wrongstat == 1 or curpar != 51){
            return 1;
        }else{
            return 0;
        }
    }
    if (memo[position][curpar][wrongstat] != -1){
        return memo[position][curpar][wrongstat];
    }
    long long total = count(position+1,wrongstat,curpar+1);
    if (curpar-1 < 51){
        total+=count(position+1,1,curpar-1);
    }else{
        total+=count(position+1,wrongstat,curpar-1);
    }
    memo[position][curpar][wrongstat] = total;
    return total;
}
int solve(int position, int wrongstat, int curpar, long long kth){
    if(position == length){
        return 0;
    }
    long long temp = count(position+1,wrongstat,curpar+1);
    if(temp <= kth){
        cout << ")";
        if(curpar-1<51){
            solve(position+1,1,curpar-1,kth-temp);
        }else{
            solve(position+1,wrongstat,curpar-1,kth-temp);
        }
    }else{
        cout << "(";
        solve(position+1,wrongstat,curpar+1,kth);
    }
    return 0;
}
int main(void){
    for(int i=0; i<110; i++){
        for (int j=0; j<110; j++){
            memo[i][j][0] = -1;
            memo[i][j][1] = -1;
        }
    }
    cin >> length;
    long long kth;
    cin >> kth;
    long long tempcount = count(0,0,51);
    if (tempcount <= kth){
        cout << -1;
    }else{
        solve(0,0,51,kth);
    }
}