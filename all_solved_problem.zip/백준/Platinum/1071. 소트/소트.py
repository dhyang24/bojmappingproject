import heapq
import sys
input = sys.stdin.readline
a = int(input())
b = []
ans = []
for i in map(int,input().split()):
    heapq.heappush(b,i)
while b:
    temp = [heapq.heappop(b),1]
    while len(b) != 0 and b[0] == temp[0]:
        heapq.heappop(b)
        temp[1]+=1
    if len(ans) == 0 or temp[0] != ans[-1]+1:
        for i in range(temp[1]):
            ans.append(temp[0])
    else:
        o = []
        for i in range(temp[1]):
            o.append(temp[0])
        if len(b) != 0:
            ans.append(heapq.heappop(b))
            for i in range(temp[1]):
                ans.append(temp[0])
        else:
            stat = False
            for i in range(len(ans)):
                if ans[len(ans)-i-1]!= temp[0]-1:
                    ans = ans[:len(ans)-i]+o+ans[len(ans)-i:]
                    stat = True
                    break
            if stat == False: 
                ans = o + ans
z = ''
for i in ans:
    z+=str(i)+' '
sys.stdout.write(z+'\n')