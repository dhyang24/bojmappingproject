
import heapq
import sys
print = sys.stdout.write
input = sys.stdin.readline
a,b,k = map(int,input().split())
thing = [[] for i in range(a)]
for p in range(b):
    q,w,e = map(int,input().split())
    thing[q-1].append([e,w-1])
hea = [[0,0]]
visited1 = [[]for i in range(a)]
visited1[0].append(0)
while hea:
    temp = heapq.heappop(hea)
    for i in thing[temp[1]]:
        if len(visited1[i[1]]) == k:
            mp = heapq.heappop(visited1[i[1]])
            heapq.heappush(visited1[i[1]],(max(mp,(temp[0]+i[0])*-1)))
            if (temp[0]+i[0])*-1 > mp:
                heapq.heappush(hea,[i[0]+temp[0],i[1]])
        else:
            heapq.heappush(visited1[i[1]],(temp[0]+i[0])*-1)
            heapq.heappush(hea,[i[0]+temp[0],i[1]])
for i in visited1:
    if len(i) != k:
        print('-1'+'\n')
    else:
        print(str(i[0]*-1)+'\n')
