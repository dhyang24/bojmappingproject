a,b = map(int,input().split())
start = 1
for i in range(a):
    temp = [start]
    for p in range(b-1):
        temp.append(temp[-1]+p*a+i+1)
    print(*temp)
    start+=(b-1)*(a)+b*i+1
    
        
