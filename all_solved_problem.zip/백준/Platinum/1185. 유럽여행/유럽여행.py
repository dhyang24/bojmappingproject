import heapq
import math
a,b = map(int,input().split())
der  = []
for i in range(a):
    der.append(int(input()))
graph = [[] for i in range(a)]
qwer = [math.inf,0]
for i in range(b):
    q,w,e = map(int,input().split())
    graph[q-1].append([e*2+der[q-1]+der[w-1],w-1])
    graph[w-1].append([e*2+der[q-1]+der[w-1],q-1])
    if der[q-1] < qwer[0]:
        qwer= [der[q-1],q-1]
    if der[w-1] < qwer[0]:
        qwer = [der[w-1],w-1]
b = []
for i in graph[qwer[1]]:
    heapq.heappush(b,i)
visited = [False for i in range(a)]
visited[qwer[1]] = True
ans = der[qwer[1]]
while b:
    temp = heapq.heappop(b)
    if visited[temp[1]]:
        continue
    visited[temp[1]] = True
    ans+=temp[0]
    for i in graph[temp[1]]:
        if visited[i[1]] == False:
            heapq.heappush(b,i)
print(ans)
