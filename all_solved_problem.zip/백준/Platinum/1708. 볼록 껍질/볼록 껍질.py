import math
def ccw(p1,p2,p3):
    ans = (p2[0]-p1[0])*(p3[1]-p1[1])-(p2[1]-p1[1])*(p3[0]-p1[0])
    if (ans<0): return 1
    elif ans>0: return -1
    else: return 0
def getangle(p1,p2):
    if (p2[0]-p1[0]) == 0:
        return math.inf
    return (p2[1]-p1[1])/(p2[0]-p1[0])
def sortbyangle(p):
    p = sorted(p,key=lambda k:k[1],reverse = True)
    p = sorted(p,key=lambda k:k[0],reverse = True)
    first = p[-1]
    p.remove(first)
    ans = sorted(p,key=lambda k:getangle(first,k), reverse = True)
    return ans+[first]
def convexshell(c):
    sortedc = sortbyangle(c)
    stack = [sortedc.pop(),sortedc.pop()]
    while len(sortedc) != 0:
        temp = sortedc.pop()
        stack.append(temp)
        while len(stack)!=2 and ccw(stack[-3],stack[-2],stack[-1]) >= 0:
            z=stack.pop() 
            stack.pop()
            stack.append(z)
    return stack
c = []
for i in range(int(input())):
    c.append(list(map(int,input().split())))
print(len(convexshell(c)))