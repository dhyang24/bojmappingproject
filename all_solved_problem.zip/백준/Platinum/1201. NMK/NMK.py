p=print;r=range;a,b,c=map(int,input().split())
if b+c-1>a or b*c<a:p(-1)
else:
    z=[i for i in r(1,b+1)][::-1];x=[i for i in r(b+1,a+1)][::-1];ans=[]
    for i in r(b):
        temp = []
        for i in r(c-1):
            try:temp.append(x.pop())
            except:break
        ans+=temp[::-1]+[z.pop()]
    p(*(x+ans))
