import sys
input = sys.stdin.readline
print = sys.stdout.write
n,m = map(int,input().split())
cow = []
thing = [[] for i in range(m)]
cow2 = [-1 for i in range(n)]
ans=0
def find(num):
    visit[num] = True
    for i in cow[num]:
        if thing[i-1] == [] or (visit[thing[i-1][0]] == False and find(thing[i-1][0])):
            cow2[num] = i-1
            thing[i-1] = [num]
            return True
    return False
for i in range(n):
    cow.append(list(map(int,input().split()))[1:])
for i in range(n):
    if cow2[i] != -1:
        ans+=1
        continue
    visit = [False for qwe in range(n)]
    if find(i):
        ans+=1
print(str(ans)+'\n')