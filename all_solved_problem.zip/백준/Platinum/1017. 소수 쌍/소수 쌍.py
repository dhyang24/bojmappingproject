thing = [True for i in range(2010)]
thing[0] = False
thing[1] = False
for i in range(2010):
    if thing[i]:
        for q in range(i*2,2010,i):
            thing[q] = False
a = int(input())
b = list(map(int,input().split()))
mi= b[0]
b = sorted(b)
answer = [False for i in range(2010)]
even = []
odd = []
for i in b:
    if i%2 == 0:
        even.append(i)
    else:
        odd.append(i)
graph = [[] for i in range(1010)]
mx = max(b)
for i in even:
    for p in odd:
        if thing[i+p]:
            if min(b)%2 == 0:
                graph[i].append(p)
            else:
                graph[p].append(i)
def dfs(n):
    global graph
    global visited
    global answer
    global mi
    if visited[n]: return 0
    visited[n] = 1
    for i in range(len(graph[n])):
        this = graph[n][i]
        if not answer[this] or dfs(answer[this]):
            answer[this] = n
            return 1
    return 0
tans = []
for qwer in (even if mi%2 == 1 else odd):
    if thing[qwer+mi] == False:
        continue
    ans=0
    answer = [False for i in range(2010)]
    answer[mi] = qwer
    answer[qwer] = mi
    for i in b:
        visited=[False for i in range(1010)]
        visited[mi] = True
        visited[qwer] = True
        if dfs(i):ans+=1
    if (ans+1) == a//2:
        tans.append(qwer)
if tans:
    print(*sorted(tans))
else:
    print(-1)