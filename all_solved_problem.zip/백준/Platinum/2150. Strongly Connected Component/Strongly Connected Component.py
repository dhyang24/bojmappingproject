import sys
sys.setrecursionlimit(10**5+1)
a,b = map(int,input().split())
graph = [[] for i in range(a)]
stack = []
visited = [False for i in range(a)]
arbitary = [-1 for i in range(a)]
now = 0
anss = []
def dfs(cur):
    global now
    arbitary[cur] = now
    now+=1;
    stack.append(cur)
    highest = arbitary[cur]
    for i in graph[cur]:
        if arbitary[i] == -1:
            highest = min(highest,dfs(i))
        elif not visited[i]:
            highest = min(highest,arbitary[i])
    if highest == arbitary[cur]:
        stuff = []
        while True:
            stuff.append(stack.pop())
            visited[stuff[-1]] = True
            stuff[-1]+=1
            if stuff[-1]-1 == cur:
                break
        anss.append(sorted(stuff))
    return highest
for i in range(b):
    q,w=map(int,input().split())
    graph[q-1].append(w-1)
for i in range(a):
    if arbitary[i] == -1:
        dfs(i)
print(len(anss))
for i in sorted(anss,key=lambda k:k[0]):
    print(*(i+[-1]))
