import sys
sys.setrecursionlimit(10**5)
input = sys.stdin.readline
print = sys.stdout.write
a = int(input())
thing = [[] for i in range(a)]
pa = [0 for i in range(a)]
height = [0 for i in range(a)]
dist = [0 for i in range(a)]
def find(cur,visited,d):
    visited[cur] = True
    global thing
    global pa
    global height
    global dist
    for i in thing[cur]:
        if visited[i[0]]:
            continue
        visited[i[0]] = True
        dist[i[0]] = d+i[1]
        height[i[0]] = height[cur]+1
        pa[i[0]] = cur
        find(i[0],visited,dist[i[0]])
for i in range(a-1):
    q,w,e=map(int,input().split())
    thing[q-1].append([w-1,e])
    thing[w-1].append([q-1,e])
find(0,[False for i in range(a)],0)
spa = [[-1 for i in range(17)] for i in range(a)]
for i in range(a):
    spa[i][0] = pa[i]
for i in range(1,17):
    for q in range(a):
        spa[q][i] = spa[spa[q][i-1]][i-1]
for i in range(int(input())):
    q,w = sorted(list(map(int,input().split())),key=lambda k:height[k-1])
    q-=1
    w-=1
    temp = [q,w]
    for p in range(16,-1,-1):
        if (2**p) & (height[w]-height[q]):
            w = spa[w][p]
    if q != w:
        for p in range(16,-1,-1):
            if spa[w][p] != spa[q][p]:
                w = spa[w][p]
                q = spa[q][p]
        w = pa[w]
    print(str(dist[temp[0]]+dist[temp[1]]-2*dist[w])+'\n')
        
    
