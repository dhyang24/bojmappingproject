import sys
from collections import deque
input = sys.stdin.readline
print = sys.stdout.write
def dfs(cur,time):
    global graph
    global visited2
    global current
    if visited2[cur]:
        return False
    visited2[cur] = True
    for i in graph[cur]:
        if i[1] <= time and (current[i[0]] == -1 or dfs(current[i[0]],time)):
            current[i[0]] = cur
            return True
    return False
def init():
    global visited2
    visited2 = [False for i in range(len(carl))]
def init2():
    global current
    current = [-1 for i in range(len(pl))]
def check(time):
    global graph
    global carl
    global pl
    init2()
    ans = 0
    for i in range(len(carl)):
        init()
        if dfs(i,time):
            ans+=1
    if ans == len(carl):
        return True
    else:
        return False
a,b = map(int,input().split())
ma = []
carl = []
pl = []
for i in range(a):
    ma.append(input())
    for q in range(b):
        if ma[-1][q] == 'C':
            carl.append([i,q])
        if ma[-1][q] == 'P':
            pl.append([i,q])
graph = [[] for i in range(len(carl))]
visited2 = [False for i in range(len(carl))]
current = [-1 for i in range(len(pl))]
for car in range(len(carl)):
    visited = [[-1 for i in range(b)] for i in range(a)]
    q = deque([carl[car],-1])
    time=1
    visited[carl[car][0]][carl[car][1]] = 0
    while len(q) != 1:
        temp = q.popleft()
        if temp == -1:
            time+=1
            q.append(-1)
            continue
        if ma[temp[0]][temp[1]] == 'P':
            for i in range(len(pl)):
                if pl[i] == [temp[0],temp[1]]:
                    graph[car].append([i,visited[temp[0]][temp[1]]])
        if temp[0] > 0 and ma[temp[0]-1][temp[1]] in ['.','P','C'] and visited[temp[0]-1][temp[1]] == -1:
            visited[temp[0]-1][temp[1]] = time
            q.append([temp[0]-1,temp[1]])
        if temp[1] > 0 and ma[temp[0]][temp[1]-1] in ['.','P','C'] and visited[temp[0]][temp[1]-1] == -1:
            visited[temp[0]][temp[1]-1] = time
            q.append([temp[0],temp[1]-1])
        if temp[0] < a-1 and ma[temp[0]+1][temp[1]] in ['.','P','C'] and visited[temp[0]+1][temp[1]] == -1:
            visited[temp[0]+1][temp[1]] = time
            q.append([temp[0]+1,temp[1]])
        if temp[1] < b-1 and ma[temp[0]][temp[1]+1] in ['.','P','C'] and visited[temp[0]][temp[1]+1] == -1:
            visited[temp[0]][temp[1]+1] = time
            q.append([temp[0],temp[1]+1])
start = 0
end = 2501
while start < end:
    mid = (start+end)//2
    if check(mid) == True:
        end = mid
        continue
    else:
        start = mid+1
        continue
if end == 2501:
    print('-1\n')
else:
    print(str(end)+'\n')
