import sys
input = sys.stdin.readline
print = sys.stdout.write
a = int(input())
c = []
d = []
for i in range(a):
    c.append(int(input()))
    d.append(c[-1])
d.sort()
dd = {}
for i in range(len(d)):
    dd[d[i]] = i
ans = 0
visited = [False for i in range(a)]
for i in range(a-1,-1,-1):
    if visited[i]: continue
    q = []
    thin=0
    cur = i
    thin+=c[cur]
    visited[cur] = True
    q.append(cur)
    while dd[c[cur]] != i:
        cur = dd[c[cur]]
        thin+=c[cur]
        visited[cur] = True
        q.append(cur)
    if cur != i:
        ans+=min(thin+d[min(q)]+d[0]*(len(q)+1),thin+d[min(q)]*(len(q)-2))
print(str(ans)+'\n')

    
