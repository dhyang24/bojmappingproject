import sys
input = sys.stdin.readline
print = sys.stdout.write
def findpi(a):
    le = len(a)
    temp = 0
    pi = [0 for i in range(le)]
    for i in range(1,le):
        while temp > 0 and a[i] != a[temp]:
            temp = pi[temp-1]
        if a[i] == a[temp]:
            pi[i] = temp+1
            temp+=1
    return pi
def kmp(a,b):
    ans = []
    pi = findpi(b)
    lea =len(a);leb=len(b);temp=0
    for i in range(lea):
        while temp > 0 and a[i] != b[temp]:
            temp = pi[temp-1]
        if a[i] == b[temp]:
            if temp == leb-1:
                ans.append(i-leb+2)
                temp = pi[temp]
            else:
                temp+=1
    return ans
a = input()
b = input().replace("\n","")
ans = list(map(str,kmp(a,b)))
print(str(len(ans))+'\n')
print(" ".join(ans)+'\n')