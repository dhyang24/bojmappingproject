#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
struct thing{
    int a,b,c;
};
vector<thing>v;
long long find(int e){
    long long su = 0;
    long long tempa,tempc;
    for(auto i:v){
        if (i.a > e){
            continue;
        }
        if (i.c > e){
            tempc = e;
        }else{
            tempc = i.c;
        }
        su+=(tempc-i.a)/i.b+1;
    }
    return su;
}
int main(void){
    int a,q,w,e;
    thing tempss;
    cin >> a;
    for(int i=0; i<a; i++){
        cin >> q >> w >> e;
        tempss.a = q;
        tempss.b = e;
        tempss.c = w;
        v.push_back(tempss);
    }
    long long int start,end,mid;
    long long temp;
    long long int tans;
    tans = -1;
    start = 0;
    end = 2147483649;
    while (start <= end){
        mid = (start+end)/2;
        temp = find(mid);
        if (temp%2 == 0){
            start = mid+1;
        } else{
            tans = mid;
            end = mid-1;
        }
    }
    if(tans==-1){
        cout << "NOTHING";
    }else{
        cout << tans << " " << find(tans)-find(tans-1) << '\n';
    }
}
