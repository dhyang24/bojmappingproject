a,b = map(int,input().split())
c = []
for i in range(a):
    c.append(input())
dp1 = [[0 for i in range(b)] for i in range(a)]
dp2 = [[0 for i in range(b)] for i in range(a)]
dp3 = [[0 for i in range(b)] for i in range(a)]
dp4 = [[0 for i in range(b)] for i in range(a)]
for i in range(a):
    for p in range(b):
        if c[i][p] == '1' and i != 0 and p != 0 and c[i-1][p-1] == '1':
            dp1[i][p] = dp1[i-1][p-1]+1
        if c[i][p] == '1' and i != 0 and p != b-1 and c[i-1][p+1] == '1':
            dp2[i][p] = dp2[i-1][p+1]+1
for i in range(a-1,-1,-1):
    for p in range(b):
        if c[i][p] == '1' and i != a-1 and p != 0 and c[i+1][p-1] == '1':
            dp3[i][p] = dp3[i+1][p-1]+1
        if c[i][p] == '1' and i != a-1 and p != b-1 and c[i+1][p+1] == '1':
            dp4[i][p] = dp4[i+1][p+1]+1
mn = 0
for i in range(a):
    for p in range(b):
        if c[i][p] == '0':
            continue
        for j in range(min(dp2[i][p],dp4[i][p]),-1,-1):
            if dp4[i-j][p+j] >= j and dp2[i+j][p+j] >= j:
                mn = max(mn,j+1)
                break
print(mn)

