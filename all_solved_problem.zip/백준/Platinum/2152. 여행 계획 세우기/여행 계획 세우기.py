import sys
input = sys.stdin.readline
print = sys.stdout.write
sys.setrecursionlimit(10**5+1)
def dfs(cur):
    global now
    global graph
    global stack
    global visited
    global arbitary
    global anss
    global things
    arbitary[cur] = now
    now+=1;
    stack.append(cur)
    highest = arbitary[cur]
    for i in graph[cur]:
        if arbitary[i] == -1:
            highest = min(highest,dfs(i))
        elif not visited[i]:
            highest = min(highest,arbitary[i])
    if highest == arbitary[cur]:
        stuff = []
        while True:
            stuff.append(stack.pop())
            visited[stuff[-1]] = True
            sccs[stuff[-1]] = things
            stuff[-1]+=1
            if stuff[-1]-1 == cur:
                break
        things+=1
        anss.append(sorted(stuff))
    return highest
def dfs2(cur):
    global anss
    if tvisited[cur]:
        return tvisited[cur]
    if cur == sccs[d-1]:
        tvisited[cur] = len(anss[cur])
        return len(anss[cur])
    tanss = -1
    for i in graph2[cur]:
        tem = dfs2(i)
        tanss = max(tanss,tem)
    if tanss == -1:
        tvisited[cur] = -1
        return -1
    else:
        tvisited[cur] = tanss+len(anss[cur])
        return tanss+len(anss[cur])
a,b,c,d = map(int,input().split())
graph = [[] for i in range(a)]
stack = []
visited = [False for i in range(a)]
arbitary = [-1 for i in range(a)]
sccs = [-1 for i in range(a)]
now = 0
things = 0
anss = []
for i in range(b):
    q,w=map(int,input().split())
    graph[q-1].append(w-1)
for i in range(a):
    if arbitary[i] == -1:
        dfs(i)
graph2 = [[] for i in range(len(anss))]
for i in range(len(anss)):
    temps = {}
    for j in anss[i]:
        for aa in graph[j-1]:
            temps[sccs[aa]] = 1
    tthing = []
    for j in temps:
        if j == i:
            continue
        graph2[i].append(j)
tvisited = [False for i in range(len(graph2))]
tt = (dfs2(sccs[c-1]))
print(str(0) if tt == -1 else str(tt))
