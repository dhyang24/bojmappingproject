from collections import deque
import sys
input = sys.stdin.readline
print = sys.stdout.write
a = int(input())
b = []
for i in range(a):
    b.append(list(map(int,input().split())))
su = 0
mx = 0
inf = 0
for i in b:
    su+=i[0]
    inf = max(inf,i[0])
b.sort(key=lambda k:su-k[0]-k[1],reverse = True)
first = b.pop()
mx = (su-first[0]-first[1])
su-=first[0]
for i in range(a-1):
    stat = False
    thing =b.pop()
    mx = max(mx,su-thing[0]-thing[1])
    su-=thing[0]
print(str(mx)+'\n')