import sys
input = sys.stdin.readline
print = sys.stdout.write
for _ in range(int(input())):
    a,b = map(int,input().split())
    c = []
    for i in range(a):
        c.append(list(input()))
    dp = [[0 for i in range(2**b)]for i in range(a)]
    tmx = 0
    for q in range(a):
        for i in range(2**b):
            stat = True
            thing = []
            do = 0
            for z in range(b):
                if 2**z&i:
                    if do == 1:
                        stat = False
                        break
                    do = 1
                    thing.append(z)
                    if c[q][z] == 'x':
                        stat = False
                        break
                else:
                    do = 0
            if not stat:
                continue
            if q == 0:
                dp[q][i] = len(thing)
                tmx = max(dp[q][i],tmx)
            else:
                mx = 0
                for l in range(2**b):
                    if dp[q-1][l] <= mx:
                        continue
                    for u in range(b):
                        stat = True
                        if 2**u & l:
                            for w in thing:
                                if abs(u-w) == 1:
                                    stat = False
                                    break
                        if not stat: break
                    if stat:
                        mx = max(dp[q-1][l],mx)
                dp[q][i] = mx + len(thing)
                tmx = max(dp[q][i],tmx)
    print(str(tmx)+'\n')