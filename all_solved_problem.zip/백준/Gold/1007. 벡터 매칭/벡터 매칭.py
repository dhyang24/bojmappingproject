import itertools
import sys
import math
input = sys.stdin.readline
for i in range(int(input())):
    a = int(input())
    b = []
    mn = math.inf
    tx,ty=0,0
    for p in range(a):
        temp = list(map(int,input().split()))
        tx+=temp[0]
        ty+=temp[1]
        b.append(temp)
    c = list(itertools.combinations(b, a//2))
    for l in range(len(c)):
        x = 0
        y=0
        qwer = list(c[l])
        for z in qwer:
            x+=z[0]
            y+=z[1]
        mn = min(mn,math.sqrt((tx-2*x)**2+(ty-2*y)**2))
    print(mn)