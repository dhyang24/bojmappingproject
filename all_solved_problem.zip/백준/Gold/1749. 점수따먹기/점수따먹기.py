import sys
import math
input = sys.stdin.readline
print = sys.stdout.write
a,b = map(int,input().split())
c = []
d = [[0 for i in range(b+1)] for i in range(a+1)]
mx = math.inf * -1
for i in range(a):
    c.append(list(map(int,input().split())))
for i in range(1,a+1):
    for p in range(1,b+1):
        d[i][p] = d[i-1][p]+d[i][p-1]+c[i-1][p-1]-d[i-1][p-1]
for i in range(1,a+1):
    for p in range(1,b+1):
        for l in range(i,a+1):
            for q in range(p,b+1):
                mx = max(mx, d[l][q]-d[i-1][q]-d[l][p-1]+d[i-1][p-1])
print(str(mx)+'\n')
