import math
a = int(input())
b = list(map(int,input().split()))
if len(b) == 1:
    print('A')
elif len(b) == 2:
    if b[0] == b[1]:
        print(b[0])
    else:
        print('A')
else:
    try:
        x = (b[1]-b[2])/(b[0]-b[1])
        y = (b[1]-(b[0]*x))
        stat = True
        for i in range(len(b)-1):
            if b[i]*x+y != b[i+1]:
                stat = False
                break
        if stat == False or int(b[-1]*x+y) != b[-1]*x+y or int(x) != x or int(y) != y:
            print('B')
        else:
            print(int(b[-1]*x+y))
    except:
        stat = True
        for i in b:
            if i != b[0]:
                stat = False
                break
        if stat == True:
            print(b[0])
        else:
            print('B')
    
