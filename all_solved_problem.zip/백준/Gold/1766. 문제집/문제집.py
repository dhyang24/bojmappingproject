import sys
import heapq
import math
input = sys.stdin.readline
a,b = map(int,input().split())
c = [i for i in range(1,a+1)]
yas = [[] for i in range(a+1)]
yas2 = [[] for i in range(a+1)]
solved = [False for i in range(a+1)]
for i in range(b):
    temp = list(map(int,input().split()))
    yas[temp[0]].append(temp[1])
    yas2[temp[1]].append(temp[0])
    if temp[1] in c:
        c.remove(temp[1])
heapq.heappush(c,math.inf)
ans = ''
while len(c) != 1:
    current = heapq.heappop(c)
    solved[current] = True
    ans+=str(current)+' '
    for i in yas[current]:
        stat = True
        for z in yas2[i]:
            if solved[z] == False:
                stat=False
                break
        if stat == True:
            heapq.heappush(c,i)
sys.stdout.write(ans)