#include <iostream>
using namespace std;
long long int dp[110][10][2048] = {0};
#define mod 1000000000
int main(void){
    int a;
    cin >> a;
    for(int i=1; i<10; i++){
        dp[0][i][1<<i] = 1;
    }
    for(int i=0; i<a; i++){
        for(int k=0; k<10; k++){
            for(int j=0; j<(1<<10); j++){
                if (k != 0){
                    dp[i+1][k-1][j|(1<<(k-1))]=(dp[i+1][k-1][j|(1<<(k-1))]+dp[i][k][j])%mod;
                }
                if(k != 9){
                    dp[i+1][k+1][j|(1<<(k+1))]=(dp[i+1][k+1][j|(1<<(k+1))]+dp[i][k][j])%mod;
                }
            }
        }
    }
    long long ans;
    ans = 0;
    for(int i=0; i<10; i++){
        ans = (ans+dp[a-1][i][(1<<10)-1])%mod;
    }
    cout << ans << '\n';
}
