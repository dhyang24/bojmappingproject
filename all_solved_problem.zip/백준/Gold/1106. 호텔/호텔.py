a,b= map(int,input().split());weight = []
for i in range(b):
   weight.append(list(map(int,input().split())))
weight.sort();dp=[0 for i in range((weight[-1][0])*(1000)+2)]
for i in range(1,len(dp)):
   stat=False
   for j in weight:
      if j[0]<=i:dp[i]=max(dp[i-j[0]]+j[1],dp[i])
   if dp[i]>=a:print(i);stat=True;break