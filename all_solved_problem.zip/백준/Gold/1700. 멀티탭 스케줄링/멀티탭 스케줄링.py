a,b = map(int,input().split())
c = list(map(int,input().split()))
multi,ans=[0 for i in range(a)],0
for i in range(b):
    stat = False
    for z in range(a):
        if multi[z] == c[i] or multi[z] == 0:
            stat = True
            multi[z] = c[i]
            break
    if stat:
        continue
    mx = 0
    for l in range(a):
        try:
            q = c[i+1:].index(multi[l])
            if mx < q:
                mx = q
                asdf = l
        except:
            asdf = l
            break
    multi[asdf] = c[i]
    ans+=1
print(ans)