import math
a,b = map(int,input().split())
mn = [-1,-1]
for i in range(1,32768):
    start = 1
    end = 32767
    while start <= end:
        mid = (start+end)//2
        if math.gcd(i,mid) == 1 and (i,mid) != (a,b):
            if mn[0] == -1 or (abs(mn[0]*b-a*mn[1])*mid*b > abs(i*b-a*mid)*b*mn[1]):
                mn = (i,mid)
        if i*b > a*mid:
            start = mid+1
        else:
            end = mid-1
print(*mn)