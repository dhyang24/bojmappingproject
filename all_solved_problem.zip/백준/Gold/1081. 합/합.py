import sys
temp = list(map(str,sys.stdin.readline().split()))
a = temp[1]
ans1 =[]
ans2 =[]
for i in range(10):
    fakeans = 0
    for k in range(len(a)):
        num =1
        if int(a[k]) == i:
            if k == 0:
                try: num = int(a[k+1:])+1
                except: pass
            else:
                if k == len(a)-1:
                    if i != 0: num = (int(a[:k])+1)
                    else: num = (int(a[:k]))
                else:
                    if i != 0: num = (int(a[k+1:])+1)+(int(a[:k]))*(10**(len(a)-k-1))
                    if i == 0: num = (int(a[k+1:])+1)+(int(a[:k])-1)*(10**(len(a)-k-1))
        elif int(a[k]) > i:
            if k == 0:
                if i != 0: num = 10**(len(a)-k-1)
                else: num = 0
            else:
                if i != 0: num = (int(a[:k])+1)*(10**(len(a)-k-1))
                else: num = (int(a[:k]))*(10**(len(a)-k-1))
        elif int(a[k]) < i:
            if k == 0: num = 0
            else: num = (int(a[:k]))*(10**(len(a)-k-1))
        fakeans+=num
    ans1.append(fakeans)
a =  str(int(temp[0])-1) if temp[0] != '0' else temp[0]
for i in range(10):
    fakeans = 0
    for k in range(len(a)):
        num =1
        if int(a[k]) == i:
            if k == 0:
                try: num = int(a[k+1:])+1
                except: pass
            else:
                if k == len(a)-1:
                    if i != 0: num = (int(a[:k])+1)
                    else: num = (int(a[:k]))
                else:
                    if i != 0: num = (int(a[k+1:])+1)+(int(a[:k]))*(10**(len(a)-k-1))
                    if i == 0: num = (int(a[k+1:])+1)+(int(a[:k])-1)*(10**(len(a)-k-1))
        elif int(a[k]) > i:
            if k == 0:
                if i != 0: num = 10**(len(a)-k-1)
                else: num = 0
            else:
                if i != 0: num = (int(a[:k])+1)*(10**(len(a)-k-1))
                else: num = (int(a[:k]))*(10**(len(a)-k-1))
        elif int(a[k]) < i:
            if k == 0: num = 0
            else: num = (int(a[:k]))*(10**(len(a)-k-1))
        fakeans+=num
    ans2.append(fakeans)
realans = 0
for i in range(10):
   realans+=(ans1[i]-ans2[i])*(i)
print(realans)