import math
import sys
input = sys.stdin.readline
a = int(input())
lis = []
dic = [[[0] for i in range(2**(a+1))] for i in range(a)]
def TSP(visited, curvis):
    global lis
    if dic[curvis][visited] != [0]: return dic[curvis][visited]
    if visited == 2**a-1:
        if lis[curvis][0] != 0:
            return lis[curvis][0]
        else:
            return math.inf
    ans = math.inf
    for i in range(a):
        if lis[curvis][i] != 0 and not (visited&(2**i)):
            ans = min(ans,TSP((2**i)|visited,i)+lis[curvis][i])
    dic[curvis][visited]=ans
    return ans
for i in range(a):
    lis.append(list(map(int,input().split())))
ans = TSP(1,0)
print(ans)