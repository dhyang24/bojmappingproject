mi,mx = map(int,input().split())
diff,sup = mx-mi+1,0
lis = [0]*1000001
for p in range(2,mx+1):
   if p**2 > mx: break
   potato = p**2-(mi%(p**2))
   if potato == p**2:
      potato = 0
   for i in range(potato,diff,p**2):
      lis[i] = 1
for i in range(diff):
   if lis[i] == 0: sup+=1
print(sup)