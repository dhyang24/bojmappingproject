def ccw(x1,y1,x2,y2,x3,y3):
    ans = (x2-x1)*(y3-y1)-(y2-y1)*(x3-x1)
    if (ans<0): return 1
    elif ans>0: return -1
    else: return 0
def touchline(p1,p2,p3,p4):
    ans = ccw(p1[0],p1[1],p2[0],p2[1],p3[0],p3[1])*ccw(p1[0],p1[1],p2[0],p2[1],p4[0],p4[1])
    ans2 = ccw(p3[0],p3[1],p4[0],p4[1],p1[0],p1[1])*ccw(p3[0],p3[1],p4[0],p4[1],p2[0],p2[1])
    if ans <=0 and ans2 <=0:
        return True
    else:
        return False
a = int(input())
b = list(map(int,input().split()))
mx = 0
for i in range(a):
    temp = 0
    for s in range(i):
        stat = True
        for z in range(s+1,i):
            if touchline([i,b[i]],[s,b[s]],[z,0],[z,b[z]]) == True:
                stat = False
                break
        if stat == True: temp+=1
    for e in range(i+1,a):
        stat = True
        for z in range(i+1,e):
            if touchline([i,b[i]],[e,b[e]],[z,0],[z,b[z]]) == True:
                stat = False
                break
        if stat == True: temp+=1
    mx = max(temp,mx)
print(mx)