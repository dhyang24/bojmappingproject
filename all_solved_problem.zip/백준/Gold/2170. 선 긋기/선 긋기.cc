#include <iostream>
#include <algorithm>
#include <vector>
#include <utility>
using namespace std;
vector<pair<int, int> > v;
int main(void){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int a;
    cin >> a;
    for (int i = 0; i < a; i++){
        int q,w;
        cin >> q >> w;
        v.push_back(make_pair(q,1));
        v.push_back(make_pair(w,-1));
    }
    sort(v.begin(),v.end());
    int now = 0;
    int ans = 0;
    for (int i=0; i<v.size(); i++){
        if (now !=  0){
            ans+=v[i].first-v[i-1].first;
        }
        now+=v[i].second;
    }
    cout << ans << '\n';
}