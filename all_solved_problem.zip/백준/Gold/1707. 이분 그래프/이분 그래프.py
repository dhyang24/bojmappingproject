import sys
input = sys.stdin.readline
print = sys.stdout.write
sys.setrecursionlimit(10**4*2)
def dfs(cur,thing):
    visited[cur] = thing
    for i in graph[cur]:
        if visited[i]:
            if visited[i] == visited[cur]:
                return -2
        else:
            if dfs(i,thing*-1) == -2:
                return -2
    return True
for i in range(int(input())):
    q,w = map(int,input().split())
    graph = [[] for i in range(q)]
    visited = [0 for i in range(q)]
    for q in range(w):
        q,w = map(int,input().split())
        graph[q-1].append(w-1)
        graph[w-1].append(q-1)
    stat = True
    for i in range(q):
        if not visited[i]:
            if dfs(i,1) == -2:
                stat = False
    print("YES\n" if stat else "NO\n")
