number = int(input())
lis = list(map(int,input().split()))
target = int(input())
def find(lis, target, startingnum):
    stat = []
    for i in range(len(lis)):
        if i == target:
            continue
        if lis[i] == startingnum:
            stat.append(i)
    if len(stat) == 0 and startingnum != target:
        return 1
    if startingnum == target:
        return 0
    su = 0
    for i in stat:
        su+=find(lis,target,i)
    return su
su = 0
for i in range(len(lis)):
    if lis[i] == -1:
        su+=find(lis,target,i)
print(su)