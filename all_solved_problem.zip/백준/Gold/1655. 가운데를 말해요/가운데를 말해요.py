import heapq
import sys
low = []
high = []
for i in range(int(sys.stdin.readline())):
    n = int(sys.stdin.readline())
    if len(low) == len(high):
        heapq.heappush(low, n*-1)
    else:
        heapq.heappush(high, n)
    if len(high)!=0 and low[0]*-1 > high[0]:
        temp = heapq.heappop(low)
        heapq.heappush(high,temp*-1)
        heapq.heappush(low,heapq.heappop(high)*-1)
    print(low[0]*-1)