import sys
import heapq
import math
input = sys.stdin.readline
asdf,b = map(int,input().split())
c = []
d = []
a = [True for i in range(b)]
for i in range(asdf):
    temp = list(map(int,input().split()))
    heapq.heappush(c,(temp[0],-temp[1]))
for i in range(b):
    heapq.heappush(d,(int(input())))
d = sorted(d)
ans = 0
temp = []
temp2 = heapq.heappop(c)
while len(d) != 0 and (len(temp)!=0 or len(c) != 0):
    zxcv = heapq.heappop(d)
    while temp2[0] <= zxcv:
        heapq.heappush(temp,temp2[1])
        try:
            temp2= heapq.heappop(c)
        except:
            temp2= (math.inf,0)
    if len(temp)!=0:
        ans+=heapq.heappop(temp)
print(ans*-1)