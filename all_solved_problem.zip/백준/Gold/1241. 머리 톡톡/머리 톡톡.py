import sys
input = sys.stdin.readline
print = sys.stdout.write
a = [0 for i in range(1000001)]
lis = []
for i in range(int(input())):
    lis.append(int(input()))
    a[lis[-1]] += 1
import math
for i in lis:
    ans = 0
    for p in range(1,math.floor(math.sqrt(i))+1):
        if i%p == 0:
            if p == math.sqrt(i):
                ans-=a[p]
            ans+=a[p]
            ans+=a[i//p]
    print(str(ans-1)+'\n')
