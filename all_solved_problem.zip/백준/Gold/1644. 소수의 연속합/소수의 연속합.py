import math
num = int(input())
a = [True for i in range(4000000)]
a[0] = False
a[1] = False
for i in range(2,math.ceil(math.sqrt(4000000))):
    if a[i] == True:
        for z in range(i*2,len(a),i):
                a[z] = False
k = []
for i in range(len(a)):
    if a[i] == True: 
        k.append(i)
ans=0
for i in range(len(k)):
    for z in range(i,len(k)):
        if sum(k[i:z+1]) == num:
            ans+=1
            break
        elif sum(k[i:z+1])>num:
            break
print(ans)