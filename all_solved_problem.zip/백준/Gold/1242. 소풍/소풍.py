import sys
a,b,ad= sys.stdin.readline().split()
a = int(a);b = int(b)
ad = int(ad)
c = a
pointer = 0
p =1
while True:
    pointer = (pointer+b-1)%c
    c-=1
    if pointer+1 == ad:
        break
    if ad > pointer:
        ad-=1
    p+=1
print(p)