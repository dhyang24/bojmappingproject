import sys
import math
import heapq
input = sys.stdin.readline
print = sys.stdout.write
a,b = map(int,input().split())
gansun = [[] for i in range(a+1)]
visited = [False for i in range(a+1)]
ans =[]
usedgansun = []
for i in range(b):
    temp = list(map(int,input().split()))
    temp2 = [temp[1],temp[0],temp[2]]
    gansun[temp[0]].append(temp)
    gansun[temp2[0]].append(temp2)
heap = []
heapq.heappush(heap,(0,1))
while len(heap) != 0:
    temp = heapq.heappop(heap)
    if visited[temp[1]] == False:
        visited[temp[1]] = True
        heapq.heappush(ans,temp[0]*-1)
        for i in gansun[temp[1]]:
            if visited[i[1]] == False:
                heapq.heappush(heap,(i[2],i[1]))
heapq.heappop(ans)
trueans = 0
while len(ans) != 0:
    trueans+=heapq.heappop(ans)
print(str(trueans*-1))