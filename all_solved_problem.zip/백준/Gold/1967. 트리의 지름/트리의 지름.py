import sys
sys.setrecursionlimit(10**5)
a = int(input())
def find(visited,node,cur):
    visited[cur] = True
    mx,mxpo = -1,-1
    stat = False
    for i in node[cur]:
        if not visited[i[0]]:
            stat = True
            visited[i[0]] = True
            temp = find(visited,node,i[0])
            if (i[1] + temp[0]) > mx:
                mx = (i[1]+temp[0])
                mxpo = temp[1]
    if not stat:
        return [0,cur]
    return [mx,mxpo]
node = [[] for i in range(a)]
for i in range(a-1):
    q,w,e = map(int,input().split())
    node[q-1].append([w-1,e])
    node[w-1].append([q-1,e])
print(find([False for i in range(a)],node,find([False for i in range(a)],node,0)[1])[0])
