import math
def ispalindrome(a):
    for i in range(len(a)//2):
        if a[i] != a[len(a)-i-1]:
            return False
    return True
a = input()
b = [math.inf]*((len(a))+1)
b[0] = 0
for i in range(len(a)):
    for p in range(1,len(a)-i+1):
        if ispalindrome(a[i:i+p]):
            b[i+p] = min(b[i+p],b[i]+1)
print(b[-1])