import sys
from collections import deque
num, iteration = map(str,input().split())
iteration = int(iteration)
length = len(num)
q = deque([num,' '])
number = 1
if length == 1 and iteration != 0:
    print(-1)
else:
    while number <= iteration:
        temp = q.popleft()
        if temp == ' ':
            number+=1
            q.append(' ')
            continue
        for i in range(length-1):
            for p in range(i+1,length):
                if i == 0 and (not (temp[i] =='0' and temp[p]=='0')and(temp[i] == '0' or temp[p] == '0')):
                    continue
                z = ''
                for qq in range(length):
                    if qq == i:
                        z+=temp[p]
                    elif qq == p:
                        z+=temp[i]
                    else:
                        z+=temp[qq]
                if z not in q:
                    q.append(z)
    q = sorted(list(q),reverse=True)
    if q[0] == ' ':
        print(-1)
    else:
        print(q[0])