import sys
input = sys.stdin.readline
a,b = map(int,input().split())
zzz = list(map(int,input().split()))
yes = [0]*40*1000001
ans = 0
def half(i,s):
    if i == len(zzz)//2:
        yes[s]+=1;return 0
    half(i+1,s)
    half(i+1,s+zzz[i])
def half1(i,s):
    global ans
    if i == a:
        ans+=yes[b-s]
        return 0
    half1(i+1,s)
    half1(i+1,s+zzz[i])
half(0,0)
half1(len(zzz)//2,0)
if b == 0:
    ans-=1
print(ans)