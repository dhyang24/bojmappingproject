a = int(input())
c = list(map(int,input().split()))
ans = 0
def twodice(lis):
    potato = []
    for p in range(len(lis)-1):
        for z in range(p+1,len(lis)):
            potato.append(lis[p]+lis[z])
    potato.remove(lis[0]+lis[5])
    potato.remove(lis[2]+lis[3])
    potato.remove(lis[1]+lis[4])
    return min(potato)
def threedice(lis):
    potato = []
    hello = []
    for p in range(len(lis)-2):
        for z in range(p+1,len(lis)):
            for l in range(z+1,len(lis)):
                potato.append((p,z,l))
    for p in potato:
        if (0 in p) and (5 in p):
            continue
        elif (2 in p) and (3 in p):
            continue
        elif (1 in p) and (4 in p):
            pass
        else:
            su = 0
            for i in p:
                su+=c[i]
            hello.append(su)
    return min(hello)
if a == 1:
    print(sum(c)-max(c))
else:
    if a >= 2:
        ans+=((a-2)**2)*min(c)*5
        ans+=(a-2)*(twodice(c))*8
        ans+=(a-2)*(min(c))*4
    ans+=(threedice(c))*4
    ans+=(twodice(c))*4
    print(ans)