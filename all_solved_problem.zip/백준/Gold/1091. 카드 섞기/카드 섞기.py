import copy
a = int(input())
current = []
for i in range(a//3):current.append(0);current.append(1);current.append(2);
start = current.copy()
q = list(map(int,input().split()))
w = list(map(int,input().split()))
ans = 0
stat = False
if start != q:
    while True:
        temp = [0 for i in range(len(current))]
        for i in range(len(w)):
            temp[i] = current[w[i]]
        current = temp
        ans+=1
        if current == q:
            stat = True
            break
        if current == start:
            break
else:
    stat = True
if stat:
    print(ans)
else:
    print(-1)
    
