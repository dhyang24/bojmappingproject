a = int(input())
thing = [0 for i in range(a)]
graph = [[] for i in range(a)]
for i in range(a):
    q = list(map(int,input().split()))
    for p in range(1,len(q)):
        graph[i].append(q[p]-1)
        graph[q[p]-1].append(i)
visited = [0 for i in range(a)]
for i in range(len(thing)):
    if visited[i]:
        continue
    do = [[i,0]]
    while do:
        do1 = do.pop()
        visited[do1[0]] = True
        for p in graph[do1[0]]:
            if not visited[p]:
                visited[p] = 1
                thing[p] = (do1[1]+1)%2
                do.append([p,thing[p]])
            
ans = []
ans2 = []
for i in range(len(thing)):
    if thing[i] == 0:
        ans.append(i+1)
    else:
        ans2.append(i+1)
print(len(ans))
print(*ans)
print(len(ans2))
print(*ans2)
