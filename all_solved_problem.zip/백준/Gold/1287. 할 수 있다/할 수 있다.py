import re
import copy
a = input()
num = 0
stat = True
for i in a:
    if i == '+' or i == '-' or i == '*' or i == '/':
        num+=1
    try:
        int(i)
    except:
        if i not in ['+','-','*','/','(',')']:
            stat = False
            break
try:
    a2 = len(list(map(int,a.replace('+',' ').replace('-',' ').replace('*',' ').replace('/',' ').replace('(','').replace(')','').split())))
except:
    stat = False
if stat:
    if a2-num != 1:
        print('ROCK')
    else:
        try:
            print(eval(a.replace("/","//")))
        except:
            print('ROCK')
else:
    print('ROCK')