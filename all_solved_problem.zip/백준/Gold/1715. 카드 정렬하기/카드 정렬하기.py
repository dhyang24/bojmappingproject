import heapq
d = []
ans = 0
for i in range(int(input())):
    heapq.heappush(d,int(input()))
while len(d) > 2:
    q= heapq.heappop(d)
    w= heapq.heappop(d)
    ans+=q
    ans+=w
    heapq.heappush(d,q+w)
if len(d) == 1:
    print(0)
else:
    print(ans+sum(d))
