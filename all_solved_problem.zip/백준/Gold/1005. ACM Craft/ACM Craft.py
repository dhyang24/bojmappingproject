import sys
sys.setrecursionlimit(2000)
def acm(a,instructions,time):
   a,lis,ans = int(a),[],0
   if a in party.keys(): return party[a]
   for i in instructions:
      if i[1] == a: lis.append(i[0])
   if len(lis) == 0: ans = int(time[a-1])
   else:
      for i in lis:
         p = acm(i,instructions,time) + int(time[a-1])
         if p > ans: ans = p
   party[a] = ans
   return party[a]
for i in range(int(sys.stdin.readline())):
   a,b = map(int,sys.stdin.readline().split())
   c = list(map(int,sys.stdin.readline().split()))
   what, instructions,party = 0,[],{}
   for i in range(b): instructions.append(list(map(int,sys.stdin.readline().split())))
   for i in c:
      if i != 0: what = 1
   if what == 1: sys.stdout.write("{potato}\n".format(potato = str(acm(sys.stdin.readline(),instructions,c))))
   else: print(0)