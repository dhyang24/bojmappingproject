#include<iostream>
#include<vector>
#include<algorithm>
#include<queue>
using namespace std;
vector<pair<int,int> > graph[100010];
int main(void){
    int n,m;
    cin >> n >> m;
    for(int i=0; i<m; i++){
        int q,w,e;
        cin >> q >> w >> e;
        graph[w-1].push_back(make_pair(e,q-1));
        graph[q-1].push_back(make_pair(e,w-1));
    }
    int ans = 0;
    priority_queue<pair<int,int> ,vector<pair<int,int> >,greater<pair<int,int> > >stuff;
    int visited[100100] = {0};
    for(int i=0; i<100100; i++){
        visited[i] = 0;
    }
    for(int i=0; i<graph[0].size(); i++){
        stuff.push(graph[0][i]);
    }
    visited[0] = 1;
    while(stuff.size()!=0){
        pair<int,int> temp = stuff.top();
        stuff.pop();
        if(visited[temp.second]){
            continue;
        }
        ans = ans+(temp.first);
        visited[temp.second] = 1;
        for(int i=0; i<graph[temp.second].size(); i++){
            if((visited[graph[temp.second][i].second]) == 0){
                stuff.push(graph[temp.second][i]);
            }
        }
    }
    cout << ans << '\n';
}
