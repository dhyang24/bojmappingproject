l,w = map(int,input().split())
dataset = []
for i in range(l):
   dataset.append(input())
maximumcount = int(input())
dic = {}
for i in dataset:
   count = 0
   for l in i:
      if l == "0":
         count+=1
   if count <= maximumcount and count%2 ==maximumcount%2:
      try: dic[i]+=1
      except: dic[i]=1
if len(dic) > 0:
   print(max(dic.values()))
else:
   print(0)