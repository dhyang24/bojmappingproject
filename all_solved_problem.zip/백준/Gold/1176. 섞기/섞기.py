a,b = map(int,input().split())
c = []
for i in range(a):
    c.append(int(input()))
dp = [[0 for i in range(2**a)] for i in range(a)]
for p in range(a):
    dp[p][2**p] = 1
for qqq in range(a):
    for l in range(a):
        for z in range(2**a):
            if not dp[l][z]:
                continue
            temp = 0
            for p in range(a):
                if 2**p&z:
                    temp+=1
            if temp != qqq:
                continue
            for p in range(a):
                if (not (2**p&z)) and abs(c[l]-c[p])>b:
                    dp[p][z|(2**p)]+=dp[l][z]
ans = 0
for i in range(a):
    ans+=dp[i][-1]
print(ans)
