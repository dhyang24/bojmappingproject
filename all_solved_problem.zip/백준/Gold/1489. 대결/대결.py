import sys
mem = {}
def find(point,i):
    oripoint = point
    if mem.get((point,i)):
        return mem[(point,i)]
    if point >= a:
        return 0
    if i >= a:
        return 0
    while c[point] > b[i]:
        point+=1
        if point >= a:
            return 0
    if b[i] > c[point]:
        point+=1
        if point>=a:
            mem[(oripoint,i)] = 2
            return 2
        mem[(oripoint,i)] = 2 + find(point,i+1)
        return mem[(oripoint,i)]
    elif b[i] == c[point]:
        mem[(oripoint,i)] = max(1+find(point+1,i+1),find(point+1,i))
        return mem[(oripoint,i)]
input = sys.stdin.readline
a = int(input())
b = sorted(map(int,input().split()),reverse = True)
c = sorted(map(int,input().split()), reverse = True)
point = 0
ans = 0
print(find(0,0))
