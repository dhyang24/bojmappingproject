a,b = map(int,input().split())
def solve(num):
    ans = num
    for p in range(1,60):
        ans+=(1<<(p-1))*(num//(1<<p))
        stat = (1<<(p-1))*(num//(1<<p))
    return ans+stat
print(solve(b)-solve(a-1))
