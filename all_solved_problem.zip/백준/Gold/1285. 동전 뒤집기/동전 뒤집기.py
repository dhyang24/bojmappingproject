import sys
ans,m = 51342789043150, []
z = int(sys.stdin.readline())
for i in range(z): m.append(input())
for k in range(1<<z):
    su = 0
    for j in range(z):
        n = 0
        for i in range(z):
            now = m[i][j]
            if ((1<<i) & k):
                if now=='T':now='H'
                else: now = 'T'
            if now == 'T': n+=1
        su+=min(n,z-n)
    ans = min(ans,su)
print(ans)