a = []
it = int(input())
for i in range(it):
    a.append(list(map(int,input().split())))
ans = 0
for i in range(it-1):
    ans+=a[i][0]*a[i+1][1]
    ans-=a[i][1]*a[i+1][0]
ans+=a[-1][0]*a[0][1]
ans-=a[-1][1]*a[0][0]
print(abs(ans)/2)