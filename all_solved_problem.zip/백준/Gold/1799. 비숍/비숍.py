import copy
import sys
input = sys.stdin.readline
a = int(input())
b = []
for i in range(a):
    b.append(list(map(int,input().split())))
c = [[] for i in range(a*2)]
for i in range(a):
    for l in range(a):
        if b[i][l] == 1:
            c[i+l+1].append(i-l+a)
answer = [False for i in range(2*a+1)]
def dfs(n):
    global c
    global visited
    global answer
    if visited[n]: return 0
    visited[n] = 1
    for i in range(len(c[n])):
        this = c[n][i]
        if not answer[this] or dfs(answer[this]):
            answer[this] = n
            return 1
    return 0
ans=0
for i in range(len(c)):
    visited=[False for i in range(2*a)]
    if dfs(i):ans+=1
print(ans)