import math
for a in range(int(input())):
    a,b = map(int,input().split())
    d = abs(a-b)
    su = 0 
    for i in range(d*2):
        if su+(i*2) >= d:
            if su+i >= d:
                print(i*2-1)
                break
            else:
                print(i*2)
                break
        else:
            su+=i*2