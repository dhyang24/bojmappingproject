import math
a,b = map(int,input().split())
ma = [[] for i in range(a)]
for i in range(a-1):
    q,w,e = map(int,input().split())
    ma[q-1].append([w-1,e])
    ma[w-1].append([q-1,e])
def find(visited,cur,ma,qwer):
    visited[cur] = True
    mn = math.inf
    if cur == qwer:
        return 0
    for qw in ma[cur]:
        if visited[qw[0]] == False:
            visited[qw[0]] = True
            temp = find(visited,qw[0],ma,qwer)
            if temp != -1: mn = min(temp+qw[1],mn)
    if mn != math.inf:
        return mn
    else:
        return -1
for i in range(b):
    q,w = map(int,input().split())
    print(find([False for i in range(a)],q-1,ma,w-1))