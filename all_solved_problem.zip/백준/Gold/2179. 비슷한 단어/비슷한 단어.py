a = int(input())
b = []
for i in range(a):
    b.append([input(),i])
tans = [-1,-1,-1]
for i in range(101):
    b.sort(key=lambda k:k[0][:i])
    for i in range(1,len(b)):
        ans = 0
        for j in range(min(len(b[i][0]),len(b[i-1][0]))):
            if b[i][0][j] == b[i-1][0][j]:
                ans+=1
            else:
                break
        if tans[-1] < ans or (tans[-1] == ans and (sorted([b[i],b[i-1]],key=lambda k:k[1])[0][1] < tans[0][1] or (sorted([b[i],b[i-1]],key=lambda k:k[1])[0][1] == tans[0][1] and sorted([b[i],b[i-1]],key=lambda k:k[1])[1][1] == tans[1][1]))):
            tans = [sorted([b[i],b[i-1]],key=lambda k:k[1])[0],sorted([b[i],b[i-1]],key=lambda k:k[1])[1],ans]
print(tans[0][0],tans[1][0],sep='\n') 
        
