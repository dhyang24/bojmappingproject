a,b = map(int,input().split())
c = set(list(map(int,input().split()))[1:])
party = []
for i in range(b):
    party.append(list(map(int,input().split()))[1:])
anss = [1]*len(party)
for z in range(len(party)):
    for i in range(len(party)):
        nobodyknows = True
        if c.intersection(party[i]):
            anss[i] = 0
            c = c.union(party[i])
print(sum(anss))
