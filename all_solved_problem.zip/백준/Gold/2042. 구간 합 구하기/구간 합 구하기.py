import sys
import math
from collections import deque
def upperbound(start, end, find, lis):
    while start < end:
        mid = (start + end) // 2
        if lis[mid] == find:
            start = mid + 1
        elif lis[mid] < find:
            start = mid + 1
        elif find < lis[mid]:
            end = mid
    return end
def merge(a,b):
    temp = 0
    for i in a:
        temp+=i
    for i in b:
        temp+=i
    return [temp]
input = sys.stdin.readline
print = sys.stdout.write
le,qwer,qwert = map(int,input().split())
q = []
for i in range(le):
    q.append(int(input()))
tree = []
for i in range(math.ceil(math.log(le,2))+1):
    temp = []
    if tree:
        for p in range(len(tree[-1])//2):
            temp.append(merge(tree[-1][p*2+1],tree[-1][p*2]))
        if len(tree[-1])%2 == 1:
            temp.append(tree[-1][-1])
    else:
        temp = [[i] for i in q]
    tree.append(temp)
for _ in range(qwer+qwert):
    a,b,c = map(int,input().split())
    if a == 1:
        b-=1
        for i in range(len(tree)):
            if i == 0:
                q[b] = c
                tree[0][b] = [c]
                continue
            temp = (b>>(i-1))-((b>>(i-1))%2)
            if (temp+1) >= len(tree[i-1]):
                tree[i][b>>i] = tree[i-1][b>>(i-1)]
            else:
                tree[i][b>>i] = [sum(tree[i-1][temp]+tree[i-1][temp+1])]
    if a == 2:
        stat = 0
        ans = 0
        bans = 0
        for i in range(math.ceil(math.log(b,2))+1):
            temp = math.ceil(math.log(b,2))-i
            if b&(2**temp):
                ans-=tree[temp][stat][0]
                stat+=1
            stat*=2
        ans+=q[b-1]
        stat = 0
        for i in range(math.ceil(math.log(c,2))+1):
            temp = math.ceil(math.log(c,2))-i
            if c&(2**temp):
                bans+=tree[temp][stat][0]
                stat+=1
            stat*=2
        print(str(ans+bans)+'\n')