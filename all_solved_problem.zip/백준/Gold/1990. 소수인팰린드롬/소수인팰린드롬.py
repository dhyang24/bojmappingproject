import math
import sys
a = [True for i in range(10000003)]
a[0] = 0
a[1] = 0
for i in range(2,math.floor(math.sqrt(10000000)+3)):
    if a[i]:
        for i in range(i*2,len(a),i):
            a[i] = False
w,b = map(int,input().split())
for i in range(w,b+1):
    if str(i) == str(i)[::-1] and a[i]:
        sys.stdout.write(str(i)+'\n')
    if i >= 10000003:
        break
sys.stdout.write('-1\n')
