import copy
import sys
def find(lis,current,vis):
    vis[ord(lis[current[0]][current[1]])-65] = True
    y,x = map(int,current)
    mx = 0
    if x != len(lis[0])-1 and (not vis[ord(lis[y][x+1])-65]):
        mx = max(mx,find(lis,[y,x+1],copy.copy(vis)))
    if x != 0 and (not vis[ord(lis[y][x-1])-65]):
        mx = max(mx,find(lis,[y,x-1],copy.copy(vis)))
    if y != 0 and (not vis[ord(lis[y-1][x])-65]):
        mx = max(mx,find(lis,[y-1,x],copy.copy(vis)))
    if y != len(lis)-1 and (not vis[ord(lis[y+1][x])-65]):
        mx = max(mx,find(lis,[y+1,x],copy.copy(vis)))
    return mx+1
input = sys.stdin.readline
a,b = map(int,input().split())
c = []
for i in range(a):
    c.append(list(input().strip()))
print(find(c,[0,0],[False for i in range(26)]))