import sys
input = sys.stdin.readline
length = int(input())
arr = list(map(int,input().split()))
p = sorted(arr,reverse = True)
iteration = int(input())
number = 0
while True:
   if iteration == 0:
      break
   if number == length-1:
      break
   '''
   for i in range(len(arr)-1):
      if arr[i] < arr[i+1]:
         temp = arr[i]
         arr[i] = arr[i+1]
         arr[i+1] = temp
         iteration -= 1
      if iteration == 0:
         break
   if arr == p:
      break
   '''
   mx,index = arr[number],number
   for i in range(number,min(length,number+iteration+1)):
      if arr[i] > mx:
         mx = arr[i]
         index = i
   iteration-=index-number
   for i in range(index,number,-1):
      arr[i] = arr[i-1]
   arr[number] = mx
   number+=1
ans = ""
for i in arr:
   ans+=str(i)+' '
print(ans)