ans = []
for i in range(1,1024):
    temp = []
    for k in range(0,10):
        if (1<<k)&i:
            temp.append(str(k))
    temp.sort(reverse = True)
    ans.append(int("".join(temp)))
ans.sort()
a = int(input())
if a > 1023:
    print(-1)
else:
    if a == 0:
        print(0)
    else:
        print(ans[a-1])