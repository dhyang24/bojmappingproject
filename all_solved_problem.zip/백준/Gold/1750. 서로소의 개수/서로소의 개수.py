import sys
import math
a = int(input())
b = []
for i in range(a):
    b.append(int(input()))
thing = [[0 for i in range(max(b)+1)] for i in range(a+1)]
for i in range(len(thing)-1):
    thing[i][b[i]] = 1
for i in range(len(thing)-1):
    for p in range(len(thing[0])):
        if i != len(thing)-1:
            thing[i+1][p]+=thing[i][p]
            if thing[i][p]:
                thing[i+1][math.gcd(p,b[i])]+=thing[i][p]
print((thing[-1][1]//2)%10000003)
            
        
