a = int(input())
b = sorted(map(int,input().split()))
ans = [0 for i in range(len(b))]
c = int(input())
d = sorted(map(int,input().split()))
while len(d):
    cur = d.pop()
    temp = []
    thing = []
    stat = False
    for i in range(len(b)):
        if b[i] >= cur:
            temp.append(i)
            thing.append(ans[i])
    for i in range(len(temp)):
        if thing[i] == min(thing):
            ans[temp[i]]+=1
            stat = True
            break
    if not stat:
        print(-1)
        break
if stat:print(max(ans))