import math
a,b = map(int,input().split())
arr = list(map(int,input().split()))
su = 0
curr = 0
mn = math.inf
for i in range(a):
    su+=arr[i]
    if su >= b:
        while su >= b:
            mn = min(i-curr+1,mn)
            su-=arr[curr]
            curr+=1
if mn == math.inf:
    print(0)
else:
    print(mn)