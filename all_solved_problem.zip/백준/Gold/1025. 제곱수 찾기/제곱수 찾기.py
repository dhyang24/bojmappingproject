import math
data = []
l,w = map(int,input().split())
for i in range(l):
   data.append(input())
ans = []
for x in range(w):
   for y in range(l):
      for xincrement in range(-w,w):
         for yincrement in range(-l,l):
            if xincrement == 0 and yincrement == 0:continue
            currentx = x
            currenty = y
            num = ''
            while True:
               if currentx < 0 or currentx >= w or currenty < 0 or currenty >=l: break
               num+=data[currenty][currentx]
               currentx = currentx + xincrement
               currenty = currenty + yincrement
               if math.sqrt(int(num))%1 == 0:
                  ans.append(int(num))
if len(ans) == 0:
   print(-1)
else:
   print(max(ans))