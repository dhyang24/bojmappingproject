a,b = int(input()),int(input())
cnt = 0
mi = None
for i in range(a,b+1):
   if i**0.5%1 == 0:
      cnt+=i
      if mi == None:
         mi = i
if cnt == 0:
   print(-1)
else:
   print(cnt)
   print(mi)