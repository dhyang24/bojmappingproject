a,b,c,d,e = map(int,input().split())
time = 0
exersize = 0
current = b
while True:
    if exersize == a:
        break
    if c-b < d:
        time = -1
        break
    if current + d <= c:
        current += d
        exersize +=1
        time+=1
    else:
        current = max(current-e,b)
        time+=1
print(time)