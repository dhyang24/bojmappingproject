import sys
a = int(input())
n = 0
m = 0
for i in map(int,input().split()):
    n = n + (i//30*10)+10
    m = m + (i//60 * 15)+15
if n < m:
    print("Y",str(n))
elif m < n:
    print("M",str(m))
else:
    print("Y M",str(m))