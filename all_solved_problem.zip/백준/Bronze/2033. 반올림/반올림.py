n = int(input())
for i in range(len(str(n))-1):
    current = (len(str(n))-i-1)
    if int(str(n)[current]) >= 5:
        n+=10**(i+1)-10**i*int(str(n)[current])
    else:
        n-=10**i*int(str(n)[current])
print(n)
