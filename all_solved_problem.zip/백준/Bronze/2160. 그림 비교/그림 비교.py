array = []
z = int(input())
for i in range(z):
    li = ''
    for p in range(5):
        li+=input()
    array.append(li)
ans = []
for i in range(z-1):
    for p in range(i+1,z):
        diff = 0
        for q in range(len(array[i])):
            if array[i][q] != array[p][q]:
                diff +=1
        ans.append([[i,p],diff])
ans = sorted(min(ans,key = lambda k: k[1])[0])
for i in ans: print(i+1,end=' ')
print()