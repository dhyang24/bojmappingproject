potato = int(input())
aleph = 0
while potato > 0:
    aleph += 1
    potato -= aleph
aleph
a = potato + aleph
if aleph%2 != 0: 
    print(str(aleph+1-a)+'/'+str(a))
else:
    print(str(a)+'/'+str(aleph+1-a))