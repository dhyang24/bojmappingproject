#include <stdio.h>
int main(void){
    double A;
    double B;
    scanf("%lf %lf",&A, &B);
    double C;
    C = A/B;
    printf("%.9lf",C);
}