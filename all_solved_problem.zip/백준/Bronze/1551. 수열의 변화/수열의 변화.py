a,b = map(int,input().split())
c = list(map(int,input().split(',')))
for i in range(b):
    temp = []
    for p in range(len(c)-1):
        temp.append(c[p+1]-c[p])
    c = temp.copy()
for i in range(len(c)):
    if i != len(c)-1:
        print(c[i],end=',')
    else:
        print(c[i])
