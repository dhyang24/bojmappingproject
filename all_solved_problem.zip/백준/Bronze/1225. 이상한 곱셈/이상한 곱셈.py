a,b = map(str,input().split())
su = 0
for i in a:
    for p in b:
        su+=int(i)*int(p)
print(su)