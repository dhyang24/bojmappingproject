a = int(input())
lis = [list(map(int, input().split())) for z in range(a)]
count = [0]*a
for i in range(a):
    yop = [0]*a
    for l in range(5):
        for q in range(a):
            if q != i and lis[q][l] == lis[i][l]:
                yop[q] = 1
    for z in yop:
        if z == 1:
            count[i]+=1
for i in range(len(count)):
    if count[i] == max(count):
        print(i+1)
        break

