import sys
p = []
z = []
lo = []
ans = []

for i in range(int(input())):
    p.append(input()[0])
for i in p:
    if not i in z:
        z.append(i)
        lo.append(1)
    elif i in z:
        for l in range(len(z)):
            if i == z[l]:
                lo[l]+=1
                if lo[l] >= 5 and  z[l] not in ans:
                    ans.append(z[l])

if ans == []:
    print('PREDAJA')
else:
    ans.sort()
    for i in ans:
        print(i,end='')
    sys.stdout.write('\n')