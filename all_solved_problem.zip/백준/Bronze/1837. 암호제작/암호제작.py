a, b = map(int,input().split())
ans = 0
yay = 0
for i in range(b-2):
    if a%(i+2) == 0:
        ans = i+2
        yay = 1
        break
if yay == 1:
    print("BAD",ans)
else:
    print("GOOD")