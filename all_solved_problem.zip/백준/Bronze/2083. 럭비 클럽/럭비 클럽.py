while True:
    a,b,c = map(str,input().split())
    if (a,b,c) == ('#','0','0'):
        break
    b,c = int(b),int(c)
    if b>17 or c>=80:
        print(a,'Senior')
    else:
        print(a,'Junior')
