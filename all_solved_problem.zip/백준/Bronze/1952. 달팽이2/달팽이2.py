a,b = map(int,input().split())
turn = 0
while True:
    a = a-1
    turn = turn+1
    if a == 0:
        print(turn-1)
        break
    b = b-1
    turn = turn+1
    if b == 0:
        print(turn-1)
        break
