for _ in range(int(input())):
    a,b  =map(str,input().split("-"))
    ans = (ord(a[0])-ord("A"))*(26**2) +(ord(a[1])-ord("A"))*(26**1) + (ord(a[2])-ord("A")) 
    if abs(ans-int(b)) <= 100:
        print("nice")
    else:
        print("not nice")