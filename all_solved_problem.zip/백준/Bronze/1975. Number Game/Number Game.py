import sys
c = int(sys.stdin.readline())
for i in range(c):
    n = int(sys.stdin.readline())

    sum = 0
    for i in range(2, n+2):
        count = 0
        quotient, remainder = divmod(n,i)
        if remainder != 0:
            continue
        else:
            while True:
                count = count + 1
                quotient, remainder = divmod(quotient,i)
                if remainder != 0: break
        sum = sum + count
    print(sum)