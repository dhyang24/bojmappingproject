a = input()
print(int(a, 16))