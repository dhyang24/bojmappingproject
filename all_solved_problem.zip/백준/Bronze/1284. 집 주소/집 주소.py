a = 0
while True:
    ans = 0
    ooo = str(input())
    if ooo == "0":
        break
    for i in ooo:
        if i == "1":
            ans = ans + 3
        elif i == "0":
            ans = ans + 5
        else:
            ans = ans + 4
    ans +=1
    print(ans)