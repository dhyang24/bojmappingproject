a = int(input())
b = list(map(int,input().split()))
total =0
for i in b:
   total+=i/max(b)*100
print(total/len(b))