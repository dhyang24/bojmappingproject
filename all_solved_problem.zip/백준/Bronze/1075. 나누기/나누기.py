n = int(input())
y = int(input())
n = str(n)[:len(str(n))-2]
for i in range(100):
    p = str(i)
    if i < 10:
        p = '0'+p
    if int(n+p)%y == 0:
        print(p)
        break