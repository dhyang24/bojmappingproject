import datetime as dt
s = list(map(int,input().split(":")))
a = dt.datetime(1000,2,2,s[0],s[1],s[2])
s = list(map(int,input().split(":")))
b = dt.datetime(1000,2,2,s[0],s[1],s[2])
sr= b-a
if b-a < dt.timedelta(0):
    sr+=dt.timedelta(0,86400)
sr = str(sr)
if len(sr) <8:
    sr = "0"+sr
print(sr)
