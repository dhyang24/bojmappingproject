a = int(input())
for i in range(a):
    c = int(input())
    if (c**2)%(10**len(str(c))) == c:
        print("YES")
    else:
        print("NO")
