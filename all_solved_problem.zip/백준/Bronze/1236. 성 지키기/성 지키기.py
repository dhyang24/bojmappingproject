a,b = map(int,input().split())
z = []
m = []
zod = []
for i in range(a):
    z.append(input())
for p in range(len(z)):
    for l in range(len(z[p])):
        if z[p][l] == 'X':
            if p not in m:
                m.append(p)
            if l not in zod:
                zod.append(l)
print(max((a-len(m)),(b-len(zod))))