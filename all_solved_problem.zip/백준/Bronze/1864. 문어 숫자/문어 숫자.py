while True:
    a = str(input())
    pos = 1
    ans = 0
    if a == "#":
        break
    for i in range(len(a)):
        if a[len(a)-i-1] == "-": ans = ans + 0*pos
        elif a[len(a)-i-1] == "\\": ans = ans + 1*pos
        elif a[len(a)-i-1] == "(": ans = ans + 2*pos
        elif a[len(a)-i-1] == "@": ans = ans + 3*pos
        elif a[len(a)-i-1] == "?":ans = ans + 4*pos
        elif a[len(a)-i-1] == ">":ans = ans + 5*pos
        elif a[len(a)-i-1] == "&":ans = ans + 6*pos
        elif a[len(a)-i-1] == "%":ans = ans + 7*pos
        elif a[len(a)-i-1] == "/":ans = ans + -1*pos
        pos = pos*8
    print(ans)