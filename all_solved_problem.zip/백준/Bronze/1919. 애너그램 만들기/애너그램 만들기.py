a = list(input())
b = list(input())
ans = 0
for i in b:
    try:a.remove(i)
    except:ans+=1
print(ans+len(a))