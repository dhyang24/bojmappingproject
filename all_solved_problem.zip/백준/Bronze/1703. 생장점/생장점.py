while True:
    a = list(map(int, input().split()))
    iteration = a[0]
    if iteration == 0:
        break
    gaji = 1
    for i in range(iteration):
        gaji = gaji*a[(2*i)+1]-a[(2*i)+2]
    print(gaji)