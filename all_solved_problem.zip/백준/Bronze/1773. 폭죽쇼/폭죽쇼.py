a,b = map(int,input().split())
c = []
ans = 0
for i in range(a):
    c.append(int(input()))
for i in range(1,b+1):
    for q in c:
        if i%q == 0:
            ans+=1
            break
print(ans)
