a = int(input())
b = input()
def check(a,b,c,d):
    if (a,b) == (c,d) or (a,b) == (d,c):
        return 1
    else:
        return 0
current = None
for i in b[::-1]:
    if not current:
        current = i
        continue
    if current == i:
        continue
    if check(current,i,'A','G'):
        current = 'C'
    elif check(current,i,'A','C'):
        current = 'A'
    elif check(current,i,'A','T'):
        current = 'G'
    elif check(current,i,'G','C'):
        current = 'T'
    elif check(current,i,'G','T'):
        current = 'A'
    elif check(current,i,'C','T'):
        current = 'G'
print(current)