for i in range(3):
    a,b = map(str, input().split())
    h1,m1,s1 = map(int,a.split(":"))
    h2,m2,s2 = map(int,b.split(":"))
    ans = 0
    for a in range(90000):
        if (h1+m1+s1)%3 == 0:
                ans+=1
        if h1 == h2 and m1 == m2 and s1 == s2:
            break 
        s1 = s1+1
        if int(s1) >= 60:
            s1 = 0
            m1 = m1+1
            if int(m1) >= 60:
                m1 = 0
                h1 = h1+1
                if int(h1) >= 24:
                    h1 = 0
    print(ans)