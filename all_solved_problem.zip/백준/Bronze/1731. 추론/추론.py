b = []
for i in range(int(input())):
    b.append(int(input()))
if b[2]-b[1] == b[1]-b[0]:
    print(b[-1]+b[1]-b[0])
else:
    print(round(b[-1]*(b[-1]/b[-2])))
          
