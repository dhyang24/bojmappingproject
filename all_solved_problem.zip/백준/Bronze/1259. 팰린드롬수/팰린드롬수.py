def palindrom(i):
   i = str(i)
   lis = ""
   for p in range(len(i)):
      lis += i[len(i)-p-1]
   return lis
while True:
   a = int(input())
   if a == 0:
      break
   if int(palindrom(a)) == a:
      print("yes")
   else:
      print("no")