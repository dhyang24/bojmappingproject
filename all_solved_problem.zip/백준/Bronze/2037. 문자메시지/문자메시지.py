a,b = map(int,input().split())
c = [['A','B','C'],['D','E','F'],['G','H','I'],['J','K','L'],['M','N','O'],['P','Q','R','S'],['T','U','V'],['W','X','Y','Z']]
e = input()
temp = -1
ans = 0
for i in e:
    if i == ' ':
        ans+=a
        temp = -2
    else:
        for q in range(8):
            for z in range(len(c[q])):
                if c[q][z] == i:
                    if temp == q:
                        ans+=b+(a*(z+1))
                    else:
                        ans+=(a*(z+1))
                    temp = q
print(ans)