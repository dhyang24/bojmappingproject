import math
a = input()
c = 0
for i in a:
    if (ord(i)-ord('a')+1) < 0:
        c+=(ord(i)-ord('a')+1)+52
    else:
        c+=(ord(i)-ord('a')+1)
stat = True
for i in range(2,math.floor(math.sqrt(c))+1):
    if c%i == 0:
        stat = False
        break
print("It is a prime word." if stat else "It is not a prime word.")
