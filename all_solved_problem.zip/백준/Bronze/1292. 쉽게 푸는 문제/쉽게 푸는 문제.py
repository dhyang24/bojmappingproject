d = []
for i in range(50):
    for p in range(i):
        d.append(i)
a,b = map(int,input().split())
ans  =0
for i in range(a-1,b):
    ans+=d[i]
print(ans)

