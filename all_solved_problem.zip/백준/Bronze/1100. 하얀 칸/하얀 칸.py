a = input()
b = input()
c = input()
d = input()
e = input()
f = input()
g = input()
h = input()
su = 0
for i in (a,c,e,g):
    num = [0,2,4,6]
    for p in num:
        if i[p] == 'F':
            su+=1
for i in (b,d,f,h):
    num = [1,3,5,7]
    for p in num:
        if i[p] == 'F':
            su+=1
print(su)