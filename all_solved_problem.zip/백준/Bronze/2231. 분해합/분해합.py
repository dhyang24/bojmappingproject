a = int(input())
ans = 0
for i in range(1,a):
   p = str(i)
   su = i
   for z in range(len(p)):
      su+=int(p[z])
   if su == a:
      ans = i
      break
print(ans)