c = []
a = []
potato = 0
for i in range(int(input())):
    c.append(input())
for o in range(len(c[0])):
    a = []
    for p in range(len(c)):
        a.append(c[p][o])
    for i in a:
        if a[0] == i:
            potato = 1
        else:
            potato = 0
            break
    if potato == 1:
        print(a[0],end='')
    else:
        print("?",end = '')