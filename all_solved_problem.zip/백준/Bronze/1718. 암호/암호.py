a = input()
b = input()
c = []
for i in a:
    c.append(ord(i)-ord('a') if i != ' ' else ord(' '))
for i in range(len(c)):
    if c[i] != ord(' '):
        c[i]-=(ord(b[i%len(b)])-ord('a')+1)
d = []
for i in c:
    if i == ord(' '):
        d.append(' ')
    else:
        d.append(chr(i+ord('a')) if i >= 0 else chr(i+26+ord('a')))
print("".join(d))