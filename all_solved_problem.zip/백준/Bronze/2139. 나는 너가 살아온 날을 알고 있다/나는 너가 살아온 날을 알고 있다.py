import datetime
while True:
    a,b,c = map(int,input().split())
    if (a,b,c) == (0,0,0):
        break
    print(int((datetime.date(c,b,a)-datetime.date(c,1,1)).days)+1)
