#include <stdio.h>
int main(void){
    long arr[10000];
    long rep,a,b,temp;
    scanf("%ld",&rep);
    for(int i = 0; i<rep;i++){
        scanf("%ld %ld",&a,&b);
        temp = a%10;
        for(int r = 1; r<b; r++){
            temp = (temp * a%10)%10;
        }
        if (temp == 0){
            arr[i] =10;
        } else{
            arr[i] = temp;
        }
    }
    for(int i=0; i<rep;i++){
        printf("%ld\n",arr[i]);
    }
}