a,b = input().split()
a = int(a)
po = [0 for i in range(a)]
ga = [0 for i in range(a)]
se = [0 for i in range(a)]
for i in b:
    if po[ord(i)-ord('A')] == 3 and max(max(po[:ord(i)-ord('A')]+[0]),max(po[ord(i)-ord('A')+1:]+[0])) <= 2:
        ga[ord(i)-ord('A')]+=1
        po = [0 for i in range(26)]
    elif po[ord(i)-ord('A')] == 4:
        ga[ord(i)-ord('A')]+=1
        po = [0 for i in range(26)]
    elif 4 in po:
        for z in range(len(po)):
            if po[z] == 4:
                po[z]-=1
    else:
        po[ord(i)-ord('A')]+=1
    if ga[ord(i)-ord('A')] >= 6:
        stat = True
        mx = 0
        for z in range(len(ga)):
            if z!= (ord(i)-ord('A')):
                mx = max(mx,ga[z])
                if ga[z] > ga[ord(i)-ord('A')]-2 and z != i:
                    stat = False
                    break
        if stat:
            if mx == 0:
                se[ord(i)-ord('A')]+=2
            else:
                se[ord(i)-ord('A')]+=1
            ga = [0 for i in range(26)]
    if se[ord(i)-ord('A')] >= 3:
        print(i)
        
            
        
    
    
