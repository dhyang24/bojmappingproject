a = [1,0,0]
repeat = int(input())
temp = 0
for i in range(repeat):
    start, destin = map(int,input().split())
    temp = a[start-1]
    a[start-1] = a[destin-1]
    a[destin-1] = temp
for i in range(3):
    if a[i] == 1:
        print(i+1)
        break