l = input()
b = input()
q = input()
c = ''
for a in (l,b,q):
    if a == 'black':
        c+='0'
    if a == 'brown':
        c+='1'
    if a == 'red':
        c+='2'
    if a == 'orange':
        c+='3'
    if a == 'yellow':
        c+='4'
    if a == 'green':
        c+='5'
    if a == 'blue':
        c+='6'
    if a == 'violet':
        c+='7'
    if a == 'grey':
        c+='8'
    if a == 'white':
        c+='9'
c = int(c[:2])* (10 ** int(c[-1]))
print(c)
