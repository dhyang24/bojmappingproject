import statistics
import sys
lis = []
while True:
    a = sys.stdin.readline()
    if not a:
        break
    for i in str(a.strip()):
        if i != ' ':
            lis.append(i)
try:
    print(*sorted(statistics.multimode(lis)),sep='')
except: pass