num = 0
a = input()
original = a
while True:
    if int(a) < 10 and len(a) != 2:
        a = '0' + a
    a = str(int(a[1])) + str(int(a[1])+int(a[0]))[-1]
    num+=1
    if int(a) == int(original):
        break
print(num)