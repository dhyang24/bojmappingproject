a = int(input())
a1 = 5
for i in range(a-1):
    a1 = a1 + (i+2)*3+1
print(a1%45678)