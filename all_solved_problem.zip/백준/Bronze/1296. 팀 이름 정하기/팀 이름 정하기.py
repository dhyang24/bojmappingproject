a = input()
l = 0
o = 0
v = 0
e = 0
lis = []
names = []
for z in a:
    if z == 'L':
       l+=1
    elif z == 'O':
        o+=1
    elif z == 'V':
        v+=1
    elif z == 'E':
        e+=1
for i in range(int(input())):
    b = input()
    names.append(b)
    temp1 = l
    temp2 = o
    temp3 = v
    temp4 = e
    for z in b:
        if z == 'L':
           temp1+=1
        elif z == 'O':
            temp2+=1
        elif z == 'V':
            temp3+=1
        elif z == 'E':
            temp4+=1
    lis.append(((temp1+temp2) * (temp1 + temp3) * (temp1 + temp4) * (temp2+temp3) * (temp2+temp4) * (temp3+temp4))%100)
mx = []
for i in range(len(lis)):
    if lis[i] == max(lis):
        mx.append(names[i])
mx.sort()
print(mx[0])