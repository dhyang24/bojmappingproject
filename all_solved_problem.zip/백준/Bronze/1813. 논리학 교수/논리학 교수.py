a = int(input())
b = list(map(int,input().split()))
ans = []
for i in range(min(b),max(b)+1):
    su = 0
    for z in b:
        if z == i:
            su+=1
    if su == i:
        ans.append(i)
if len(ans) == 0:
    if 0 in b:
        print(-1)
    else:
        print(0)
else:
    print(max(ans))