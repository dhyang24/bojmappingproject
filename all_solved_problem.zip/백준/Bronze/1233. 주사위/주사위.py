from collections import Counter
def my_mode(sample):
    potatopie = Counter(sample)
    return [z for z, asq in potatopie.items() if asq == potatopie.most_common(1)[0][1]]
a,b,c = map(int,input().split())
ayu = []
for i in range(1,a+1):
    for l in range(1, b+1):
        for z in range(1, c+1):
            ayu.append(i+l+z)
print(min(my_mode(ayu)))