a = int(input())
lis = map(int,input().split())
size = int(input())
ans = 0
for i in lis:
    if i % size == 0:
        ans+=(i//size)*size
    else:
        ans+=((i//size)+1)*size
print(ans)