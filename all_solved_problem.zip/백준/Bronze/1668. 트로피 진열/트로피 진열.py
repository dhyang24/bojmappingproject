a = int(input())
b = []
for i in range(a):
    b.append(int(input()))
ans = 0
ans2 = 0
temp = 0
for i in range(0,len(b)):
    if temp < b[i]:
        ans+=1
        temp = b[i]
temp = 0
for i in range(len(b)-1,-1,-1):
    if temp < b[i]:
        ans2+=1
        temp = b[i]
print(ans,ans2,sep='\n')
