import sys
qewr=int(sys.stdin.readline())
ans = 0
for i in range(qewr):
    b=int(sys.stdin.readline())
    ans = ans + (b-1)
print(ans+1)