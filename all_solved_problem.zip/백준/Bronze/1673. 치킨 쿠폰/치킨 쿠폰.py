import sys
while True:
    a = sys.stdin.readline()
    if not a:
        break
    a,b = map(int,a.split())
    if a == 0:
        print(0)
        break
    ans = 0
    temp = 0
    while a > 0:
        ans+=a
        temp+=a
        a = temp//b
        temp = temp%b
    print(ans)
