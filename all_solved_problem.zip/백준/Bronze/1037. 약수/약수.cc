#include <stdio.h>
int main(void){
    int a;
    scanf("%d",&a);
    int b[a];
    for (int i=0;i<a;i++){
        scanf("%d",&b[i]);
    }
    int min = b[0];
    int max = b[0];
    for (int i=0;i<a;i++){
        if (min > b[i]){
            min = b[i];
        }
        if (max < b[i]){
            max = b[i];
        }
    }
    printf("%d",min*max);
}