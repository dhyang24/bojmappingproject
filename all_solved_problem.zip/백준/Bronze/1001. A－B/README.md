# [Bronze V] A-B - 1001 

[문제 링크](https://www.acmicpc.net/problem/1001) 

### 성능 요약

메모리: 1112 KB, 시간: 0 ms

### 분류

구현(implementation), 사칙연산(arithmetic), 수학(math)

### 문제 설명

<p>두 정수 A와 B를 입력받은 다음, A-B를 출력하는 프로그램을 작성하시오.</p>

### 입력 

 <p>첫째 줄에 A와 B가 주어진다. (0 < A, B < 10)</p>

### 출력 

 <p>첫째 줄에 A-B를 출력한다.</p>

