a,b = map(int,input().split())
i = 0
cur = 1
while i < a:
    if str(b) in str(cur):
        cur+=1
        continue
    else:
        i+=1
        cur+=1
print(cur-1)
