while True:
    a,su = input(),0
    if a == '#':
        break
    for i in a:
        if i in ('a','e','i','o','u','A','E','I','O','U'):
            su+=1
    print(su)