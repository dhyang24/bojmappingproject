a,b,c = map(int, input().split())
d= c - b
e = 0
f = 0
if (b == c) or (b > c):
    print("-1")
else:
    print (int((a/d)+1))
        
