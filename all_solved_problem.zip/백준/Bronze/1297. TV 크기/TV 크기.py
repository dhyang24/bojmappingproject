a,b,c = map(int, input().split())
r = a / ((b ** 2 + c ** 2) ** 0.5)
print(str(int(r * b))+" "+str(int(r * c)))