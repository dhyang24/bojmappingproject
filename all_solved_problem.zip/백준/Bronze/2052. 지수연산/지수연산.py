import sys
qwer=int(sys.stdin.readline())
ans = 2
for i in range(qwer+1):
    ans = ans/2
print(format(ans,"2."+str(qwer)+"f"))