import statistics
a = str(input())
tally = []
for i in a:
   temp = ord(i)
   if temp >=97:
      temp = temp-32
   tally.append(temp)
zel = statistics.multimode(tally)
if len(zel) == 1:
   print(chr(zel[0]))
else:
   print("?")