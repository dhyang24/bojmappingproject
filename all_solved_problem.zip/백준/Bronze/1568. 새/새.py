a = int(input())
i=1
cnt=0
while True:
    cnt+=1
    a-=i
    i+=1
    if a<i:
        i=1
    if a<0:
        break
print(cnt-1)