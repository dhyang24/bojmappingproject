a,b,c,d,e = map(int,input().split())
for i in range(min(a,b,c,d,e),a*b*c*d*e):
    su = 0
    if i%a == 0:su+=1
    if i%b == 0:su+=1
    if i%c == 0:su+=1
    if i%d == 0:su+=1
    if i%e == 0:su+=1
    if su > 2:
        print(i)
        break