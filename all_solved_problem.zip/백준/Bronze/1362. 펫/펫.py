testcase = 1
gay = True
while True:
    b,a = map(int,input().split())
    if (a,b) == (0,0):break
    currentweight = a
    stat = True
    while True:
        instruction,num = map(str,input().split())
        
        num = int(num)
        if instruction == 'F':
            currentweight+=num
        elif instruction == 'E':
            currentweight-=num
        else:
            break
        if currentweight <= 0:
            stat = False
    if stat == False:
        print(testcase,'RIP')
    elif ((1/2)*b)>= currentweight or currentweight >=(2*b):
        print(testcase,':-(')
    else:
        print(testcase,':-)')
    testcase+=1
    currentweight = a
    stat = True