from collections import deque
a = deque(list(map(int,input().split(":"))))
stuff = [[a[0],a[1],a[2]],[a[1],a[0],a[2]],[a[2],a[1],a[0]],[a[0],a[2],a[1]],[a[1],a[2],a[0]],[a[2],a[0],a[1]]]
ans=0
for i in stuff:
    if i[0] > 0 and i[0] < 13 and i[1] < 60 and i[2] < 60:
        ans+=1
print(ans)
