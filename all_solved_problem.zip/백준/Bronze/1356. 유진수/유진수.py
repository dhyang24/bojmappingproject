a = input()
stat = False
for i in range(1,len(a)):
    right = a[i:]
    left = a[:i]
    rightsu = 1
    leftsu = 1
    for z in right:
        rightsu*=int(z)
    for p in left:
        leftsu*=int(p)
    if rightsu == leftsu:
        stat = True
        break
if stat == True:
    print('YES')
else:
    print('NO')