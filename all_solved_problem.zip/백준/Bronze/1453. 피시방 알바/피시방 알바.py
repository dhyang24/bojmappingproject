a = int(input())
b = map(int,input().split())
array= []
count =0
for i in b:
    if i in array:
        count+=1
    else:
        array.append(i)
print(count)
