a,b = map(int,input().split())
c = sum(map(int,input().split()))
d = sum(map(int,input().split()))
print(c-d)