a = str(input())
status = 0
ans = 0
for i in a:
   if i != ' ':
      if status == 0:
         status =1
         ans+=1
   else:
      if status == 1:
         status = 0
print(ans)