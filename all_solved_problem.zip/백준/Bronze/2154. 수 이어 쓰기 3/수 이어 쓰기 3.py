a = int(input())
d = ""
for i in range(1,a+1):
    d+=str(i)
ans = -1
for i in range(len(d)):
    if d[i:i+len(str(a))] == str(a):
        ans = i
        break
print(ans+1)