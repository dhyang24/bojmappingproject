a,b,c =map(int,input().split())
lis = [0 for i in range(a)]
cur = 0
lis[cur] = 1
while True:
    if b in lis:
        break
    if lis[cur]%2 == 0:
        cur = (cur-c)%a
    else:
        cur = (cur+c)%a
    lis[cur]+=1
print(sum(lis)-1)
