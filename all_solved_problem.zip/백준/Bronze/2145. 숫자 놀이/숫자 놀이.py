while True:
    a = int(input())
    if a == 0:
        break
    while len(str(a)) != 1:
        thing = 0
        for i in str(a):
            thing+=int(i)
        a = thing
    print(a)
