import datetime
import calendar
a,b = map(int,input().split())
print(calendar.day_name[datetime.datetime(2007,a,b).weekday()][:3].upper())
