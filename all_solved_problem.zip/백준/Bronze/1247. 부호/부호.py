import sys
potato = 0
for i in range(3):
    for a in range(int(sys.stdin.readline())):
        potato = potato+ int(sys.stdin.readline())
    if potato > 0:
        print("+")
    elif potato < 0:
        print("-")
    elif potato == 0:
        print("0")
    potato = 0
