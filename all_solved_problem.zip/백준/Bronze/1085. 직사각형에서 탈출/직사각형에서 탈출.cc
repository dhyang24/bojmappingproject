#include <stdio.h>
int main(void){
    int dis1,dis2,c,d;
    scanf("%d %d %d %d",&dis1,&dis2,&c,&d);
    int dis3,dis4;
    dis3 = c-dis1;
    dis4 = d-dis2;
    if (dis1 < dis2){
        if(dis1<dis3){
            if(dis1<dis4){
                printf("%d",dis1);
            } else {
                printf("%d",dis4);
            }
        } else if (dis3 < dis4){
            printf("%d",dis3);
        } else{
            printf("%d",dis4);
        }
    } else if(dis2<dis3){
        if(dis2<dis3){
            if(dis2<dis4){
                printf("%d",dis2);
            } else {
                printf("%d",dis4);
            }
        } else if (dis3 < dis4){
            printf("%d",dis3);
        } else{
            printf("%d",dis4);
        }
    } else if(dis3<dis4){
        printf("%d",dis3);
    } else{
        printf("%d",dis4);
    }
}