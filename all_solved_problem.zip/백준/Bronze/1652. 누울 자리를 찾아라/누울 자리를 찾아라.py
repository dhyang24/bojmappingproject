a = int(input())
data = []
for i in range(a):
   data.append(input())
cnt = 0
for i in range(a):
   z = -1
   while True:
      if z >= a-2:
         break
      z+=1
      if data[i][z] == '.' and data[i][z+1] == '.':
         cnt+=1
         while data[i][z+1] == '.':
            z+=1
            if z>= a-1:
               break 
print(cnt,end=' ')
cnt = 0
for z in range(a):
   i = -1
   while True:
      if i >= a-2:
         break
      i+=1
      if data[i][z] == '.' and data[i+1][z] == '.':
         cnt+=1
         while data[i+1][z] == '.':
            i+=1
            if i >= a-1:
               break
      
print(cnt)