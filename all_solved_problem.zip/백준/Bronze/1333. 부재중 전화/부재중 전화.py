n,l,d = map(int,input().split())
for i in range(10000):
    if i*d >= n*(l+5)-5:
        print(i*d)
        break
    elif l <= (i*d)%(l+5) <=l+4:
        print(int(i*d))
        break