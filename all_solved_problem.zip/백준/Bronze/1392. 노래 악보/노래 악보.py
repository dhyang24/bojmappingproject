a,b = map(int,input().split())
ans = []
for i in range(a):
    for q in range(int(input())):
        ans.append(i+1)
for i in range(b):
    print(ans[int(input())])